package org.pcl.tms.Mapper;

import org.pcl.tms.Model.ContainerType;

import java.util.List;

public interface ContainerTypeMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(ContainerType record);

    int insertSelective(ContainerType record);

    ContainerType selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(ContainerType record);

    int updateByPrimaryKey(ContainerType record);

    List<ContainerType> selectAll();
}