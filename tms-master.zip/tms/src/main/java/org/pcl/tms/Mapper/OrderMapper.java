package org.pcl.tms.Mapper;


import org.apache.ibatis.annotations.Param;
import org.pcl.tms.Model.Order;

import java.util.List;

public interface OrderMapper {
    int deleteByPrimaryKey(String id);

    int insert(Order record);

    int insertSelective(Order record);

    Order selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(Order record);

    int updateByPrimaryKey(Order record);

    List<Order> selectByCondition(@Param("state")int state, @Param("order")String order, @Param("rule")String rule,@Param("type")int type);

    Order selectByDriverOrderID(@Param("driver_order_id") String driverOrderId);

    List<Order> CountCurrentDay();

    List<Order> selectBybinfo(@Param("business_info_id")String business_info_id);

    List<Order> selectByType(@Param("type")int state ,@Param("order")String order, @Param("rule")String rule);

    List<Order> selectAll(
            @Param("order")String order,
            @Param("rule")String rule,
            @Param("type")int type);

    List<Order> selectFeeOrders(@Param("order")String order, @Param("rule")String rule);

    int countAllOrders(@Param("type")int type);

    int countByCondition(@Param("state")int state,
                         @Param("type")int type);

    int countByType(@Param("type")int type);

    int unbindOrder(Order record);

    int countToday();

    int countWeek();

    int countMonth();

    int count7dayByCondition(@Param("type")int type);

}