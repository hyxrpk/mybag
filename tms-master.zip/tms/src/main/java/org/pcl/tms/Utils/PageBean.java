package org.pcl.tms.Utils;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;
@Data
@Setter
@Getter
public class PageBean<T> {
    private int total;    //总的记录条数。查询数据库得到的数据
    private List<T> list;
    private int pageNum;    //当前页,从请求那边传过来。
    private int pageSize;    //每页显示的数据条数。
    private int size;
    // 可能对应startRow
    private int startRow;
    private int endRow;
    private int pages;
    private int prePage;
    private int nextPage;
    private boolean isFirstPage;
    private boolean isLastPage;
    private boolean hasPreviousPage;
    private boolean hasNextPage;
    private int navigatePages;
    private ArrayList navigatepageNums;
    private int navigateFirstPage;
    private int navigateLastPage;


    //需要计算得来
//    private int pages;



    //构造方法中将pageNum，pageSize，totalRecord获得
    public PageBean(int pageNum,int pageSize,List<T> list) {

        this.pageNum = pageNum;
        this.pageSize = pageSize;
        this.total = list.size();
//        if (pageNum == 0) {
//            this.pageNum = 1;
//        }
//        if (pageSize == 0) {
//            this.pageSize = list.size();
//        }
        //totalPage 总页数
        if (this.total % this.pageSize == 0) {
            //说明整除，正好每页显示pageSize条数据，没有多余一页要显示少于pageSize条数据的
            this.pages = this.total / this.pageSize;
        } else {
            //不整除，就要在加一页，来显示多余的数据。
            this.pages = this.total / this.pageSize + 1;
        }

        this.prePage = pageNum-1;
        this.nextPage = pageNum+1;
        if (this.pageNum==1){
            this.isFirstPage =true;
        }else{
            this.isFirstPage=false;
        }
        if (this.pages ==this.pageNum){
            this.isLastPage =true;
        }else{
            this.isLastPage=false;
        }
        if (this.pageNum!=1){
            this.hasPreviousPage = true;
        }else {
            this.hasPreviousPage=false;
        }
        if (this.pageNum<this.pages){
            this.hasNextPage =true;
        }else {
            this.hasNextPage=false;
        }

        // startRow
        this.startRow = (this.pageNum-1)*this.pageSize+1;
        // endRow
        if (this.pageSize*this.pageNum>total){
            this.endRow= this.total;
            this.size = this.endRow-this.startRow+1;
        }else if (this.pageSize*this.pageNum<total){
            this.endRow = this.pageNum * this.pageSize;
            this.size = this.pageSize;
        }else {
            this.isLastPage=true;
        }
        if (this.pages!=0){
            this.navigateFirstPage=1;
            this.navigateLastPage= this.pages;
            ArrayList arr = new ArrayList();
            for (int i=1; i <=this.pages;i++){
                arr.add(i);
            }
            this.navigatepageNums=arr;
        }else{
            this.navigateFirstPage=0;
            this.navigateLastPage=0;
            this.navigatepageNums=null;
        }
        this.list = list.subList(startRow-1,endRow);
    }
}