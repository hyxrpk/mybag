package org.pcl.tms.Mapper;

import org.pcl.tms.Model.ExtensionFee;

import java.util.List;

public interface ExtensionFeeMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(ExtensionFee record);

    int insertSelective(ExtensionFee record);

    ExtensionFee selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(ExtensionFee record);

    int updateByPrimaryKey(ExtensionFee record);

    List<ExtensionFee> selectAll();
}