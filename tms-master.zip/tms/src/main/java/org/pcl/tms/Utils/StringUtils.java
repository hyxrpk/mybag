package org.pcl.tms.Utils;

public class StringUtils {

    public static boolean IsNullStr(String a){
        if (a.equals("")|| a.length()==0 || a ==null || a.isEmpty()){
            return false;
        }
        return true;
    }


}
