package org.pcl.tms.Controller.Request;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.pcl.tms.Model.Client;
import org.pcl.tms.Model.Contract;
import org.pcl.tms.Model.Factory;

import java.util.List;

@Data
@Setter
@Getter
public class InsertClientReq {
    private Client client;
    private List<Factory> factory;
    private Contract contract;
}
