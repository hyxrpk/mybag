package org.pcl.tms.Utils;


import com.itextpdf.text.*;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import org.mybatis.spring.annotation.MapperScan;
import org.pcl.tms.Controller.Request.InsertOrderReq;
import org.pcl.tms.Mapper.CarMapper;
import org.pcl.tms.Mapper.ClientMapper;
import org.pcl.tms.Mapper.DriverMapper;
import org.pcl.tms.Mapper.FactoryMapper;
import org.pcl.tms.Model.Client;
import org.pcl.tms.Model.Driver;
import org.pcl.tms.Model.Factory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.ResourceUtils;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.io.*;
import java.util.List;

@Component
public class PDFUtil {


    @Autowired
    private ClientMapper clientMapper;
    @Autowired
    private CarMapper carMapper;
    @Autowired
    private DriverMapper driverMapper;

    public void setClientMapper(ClientMapper clientMapper) {
        this.clientMapper = clientMapper;
    }

    public void setCarMapper(CarMapper carMapper) {
        this.carMapper = carMapper;
    }

    public void setDriverMapper(DriverMapper driverMapper) {
        this.driverMapper = driverMapper;
    }


    private static PDFUtil pdfUtil;

    @PostConstruct
    public void init() {
        pdfUtil = this;
        pdfUtil.clientMapper = this.clientMapper;
        pdfUtil.driverMapper = this.driverMapper;
        pdfUtil.carMapper = this.carMapper;
    }

    public void CreatePDF(String fileName, InsertOrderReq req) throws Exception {
        // 字体
        File file = ResourceUtils.getFile("classpath:templates/SIMYOU.TTF");
        BaseFont baseFont = BaseFont.createFont(file.getPath(), BaseFont.IDENTITY_H, BaseFont.NOT_EMBEDDED);
        Font chinesefont = new Font(baseFont);
        chinesefont.setColor(BaseColor.BLACK);
        chinesefont.setSize(8);

        // 文件存储位置
        File descFile = new File(fileName);

        Document document = new Document(PageSize.A4);
        PdfWriter.getInstance(document, new FileOutputStream(descFile));

        document.open();

        // 创建表格
        Paragraph FirstTile = new Paragraph("深圳市神驼物流科技有限公司\n", chinesefont);
        FirstTile.setAlignment(Element.ALIGN_CENTER);
        document.add(FirstTile);
        Paragraph SecondTile = new Paragraph("Acecamel Logistics Technology (ShenZhen) Co., Ltd. \n WEBSITE:www.Acecamel.com \n Tel:4006560303 \n\n", chinesefont);
        SecondTile.setAlignment(Element.ALIGN_CENTER);
        document.add(SecondTile);

        PdfPTable table = new PdfPTable(8);//生成一个8列的表格
        PdfPCell cell;
        int FixedSize = 15;
        // new 1 line
        cell = new PdfPCell(new Phrase("港口集装箱运输委托作业单", chinesefont));
        cell.setFixedHeight(FixedSize);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setColspan(8);
        table.addCell(cell);

        // 第一行
        cell = new PdfPCell(new Phrase("客户名称", chinesefont));
        cell.setFixedHeight(FixedSize);
        table.addCell(cell);

//        Client client = pdfUtil.clientMapper.selectByPrimaryKey(req.getOrder().getClientId());
        cell = new PdfPCell(new Phrase(req.getClient().getClientName(), chinesefont));
        cell.setFixedHeight(FixedSize);
        cell.setColspan(2);
        table.addCell(cell);


        cell = new PdfPCell(new Phrase("进出口", chinesefont));
        cell.setFixedHeight(FixedSize);
        table.addCell(cell);

        String OrderType = "";
        if (req.getBusinessInfo().getOrderType() == 1) {
            OrderType = "出口";
        } else if (req.getBusinessInfo().getOrderType() == 2) {
            OrderType = "进口";
        } else if (req.getBusinessInfo().getOrderType() == 3) {
            OrderType = "渡柜";
        }
        cell = new PdfPCell(new Phrase(OrderType, chinesefont));
        cell.setFixedHeight(FixedSize);
        cell.setColspan(4);
        table.addCell(cell);

        //第二行
        cell = new PdfPCell(new Phrase("订单号", chinesefont));
        cell.setFixedHeight(FixedSize);
        table.addCell(cell);

        cell = new PdfPCell(new Phrase(req.getOrder().getId(), chinesefont));
        cell.setFixedHeight(FixedSize);
        cell.setColspan(2);
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("预约到厂时间", chinesefont));
        cell.setFixedHeight(FixedSize);
        table.addCell(cell);

        String yuyueDaochang = DateUtil.dateToStringTime(req.getBusinessInfo().getYuyueDaochangTime());
        cell = new PdfPCell(new Phrase(yuyueDaochang, chinesefont));
        cell.setFixedHeight(FixedSize);
        cell.setColspan(4);
        table.addCell(cell);

        //第三行
        cell = new PdfPCell(new Phrase("车牌号", chinesefont));
        cell.setFixedHeight(FixedSize);
        table.addCell(cell);

        cell = new PdfPCell(new Phrase(req.getExtentionInfo().getCarNum(), chinesefont));
        cell.setFixedHeight(FixedSize);
        cell.setColspan(2);
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("司机姓名", chinesefont));
        cell.setFixedHeight(FixedSize);
        table.addCell(cell);

        Driver driver = pdfUtil.driverMapper.selectByPrimaryKey(req.getDriverOrderInfo().getDriverId());
        cell = new PdfPCell(new Phrase(driver.getDriverName(), chinesefont));
        cell.setFixedHeight(FixedSize);
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("联系电话", chinesefont));
        cell.setFixedHeight(FixedSize);
        table.addCell(cell);

        cell = new PdfPCell(new Phrase(driver.getDriverPhone(), chinesefont));
        cell.setFixedHeight(FixedSize);
        cell.setColspan(2);
        table.addCell(cell);

        //第四行
        //第五行
        //一个工厂
        List<Factory> factories = req.getExtentionInfo().getFactorys();
        for (Factory fac : factories) {
            // 循环第一行

            cell = new PdfPCell(new Phrase("装卸货工厂", chinesefont));
            cell.setFixedHeight(FixedSize);
            table.addCell(cell);

            cell = new PdfPCell(new Phrase(fac.getFactoryName(), chinesefont));
            cell.setFixedHeight(FixedSize);
            cell.setColspan(2);
            table.addCell(cell);

            cell = new PdfPCell(new Phrase("联系人", chinesefont));
            cell.setFixedHeight(FixedSize);
            table.addCell(cell);

            cell = new PdfPCell(new Phrase(fac.getFactoryContact(), chinesefont));
            cell.setFixedHeight(FixedSize);
            table.addCell(cell);

            cell = new PdfPCell(new Phrase("联系电话", chinesefont));
            cell.setFixedHeight(FixedSize);
            table.addCell(cell);

            cell = new PdfPCell(new Phrase(fac.getFactoryPhone(), chinesefont));
            cell.setFixedHeight(FixedSize);
            cell.setColspan(2);
            table.addCell(cell);

            //循环第二行
            cell = new PdfPCell(new Phrase("工厂地址", chinesefont));
            cell.setFixedHeight(FixedSize);
            table.addCell(cell);

            cell = new PdfPCell(new Phrase(fac.getFactoryAddress(), chinesefont));
            cell.setFixedHeight(FixedSize);
            cell.setColspan(7);
            table.addCell(cell);

        }

//        第六行
        cell = new PdfPCell(new Phrase("S/O号", chinesefont));
        cell.setFixedHeight(FixedSize);
        table.addCell(cell);

        cell = new PdfPCell(new Phrase(req.getBusinessInfo().getSoNum(), chinesefont));
        cell.setFixedHeight(FixedSize);
        cell.setColspan(2);
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("客户委托号", chinesefont));
        cell.setFixedHeight(FixedSize);
        table.addCell(cell);

        if (req.getBusinessInfo().getClientOrderNum()==null){
            cell = new PdfPCell(new Phrase("", chinesefont));
        }else {
            cell = new PdfPCell(new Phrase(req.getBusinessInfo().getClientOrderNum(), chinesefont));
        }
        cell.setFixedHeight(FixedSize);
        cell.setColspan(4);
        table.addCell(cell);

        //第七行
        cell = new PdfPCell(new Phrase("柜号", chinesefont));
        cell.setFixedHeight(FixedSize);
        table.addCell(cell);

        if (req.getDriverOrderInfo().getContainerNum()==null ) {
            cell = new PdfPCell(new Phrase("", chinesefont));
        }else{
            cell = new PdfPCell(new Phrase(req.getDriverOrderInfo().getContainerNum(), chinesefont));
        }
        cell.setFixedHeight(FixedSize);
        cell.setColspan(2);
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("封条号", chinesefont));
        cell.setFixedHeight(FixedSize);
        table.addCell(cell);

        if (req.getDriverOrderInfo().getSealNum()==null){
            cell = new PdfPCell(new Phrase("", chinesefont));
        }else {
            cell = new PdfPCell(new Phrase(req.getDriverOrderInfo().getSealNum(), chinesefont));
        }
        cell.setFixedHeight(FixedSize);
        cell.setColspan(4);
        table.addCell(cell);

        // 第8行
        cell = new PdfPCell(new Phrase("柜型", chinesefont));
        cell.setFixedHeight(FixedSize);
        table.addCell(cell);

        cell = new PdfPCell(new Phrase(req.getExtentionInfo().getContainer(), chinesefont));
        cell.setFixedHeight(FixedSize);
        cell.setColspan(2);
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("小柜摆放位置", chinesefont));
        cell.setFixedHeight(FixedSize);
        table.addCell(cell);

        if (req.getBusinessInfo().getContainerPosition()==null){
            cell = new PdfPCell(new Phrase("", chinesefont));
        }else {
            cell = new PdfPCell(new Phrase(req.getBusinessInfo().getContainerPosition(), chinesefont));
        }
        cell.setFixedHeight(FixedSize);
        cell.setColspan(4);
        table.addCell(cell);

        //第九行
        cell = new PdfPCell(new Phrase("柜重", chinesefont));
        cell.setFixedHeight(FixedSize);
        table.addCell(cell);
        if (req.getDriverOrderInfo().getContainerWeight()==null){
            cell = new PdfPCell(new Phrase("", chinesefont));
        }else {
            cell = new PdfPCell(new Phrase(req.getDriverOrderInfo().getContainerWeight().toString(), chinesefont));
        }
        cell.setFixedHeight(FixedSize);
        cell.setColspan(2);
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("货重", chinesefont));
        cell.setFixedHeight(FixedSize);
        table.addCell(cell);

        cell = new PdfPCell(new Phrase(req.getBusinessInfo().getOrderWeight().toString(), chinesefont));
        cell.setFixedHeight(FixedSize);
        cell.setColspan(4);
        table.addCell(cell);

        // 第十行
        cell = new PdfPCell(new Phrase("截补料时间", chinesefont));
        cell.setFixedHeight(FixedSize);
        table.addCell(cell);

        String jiebuliaoTime = DateUtil.dateToStringTime(req.getBusinessInfo().getLatestHuanguiTime());
        cell = new PdfPCell(new Phrase(jiebuliaoTime, chinesefont));
        cell.setFixedHeight(FixedSize);
        cell.setColspan(2);
        table.addCell(cell);


        cell = new PdfPCell(new Phrase("截柜时间", chinesefont));
        cell.setFixedHeight(FixedSize);
        table.addCell(cell);

        String jieguiTime = DateUtil.dateToStringTime(req.getBusinessInfo().getLatestHuanguiTime());
        cell = new PdfPCell(new Phrase(jieguiTime, chinesefont));
        cell.setFixedHeight(FixedSize);
        cell.setColspan(4);
        table.addCell(cell);

        //第十一行
        cell = new PdfPCell(new Phrase("截关时间", chinesefont));
        cell.setFixedHeight(FixedSize);
        table.addCell(cell);

        //TODO: 不知道是啥
        if (req.getFromPHYInfo().getJieguanShijian()==null){
            cell = new PdfPCell(new Phrase("", chinesefont));
        }else {
            String jieguanTime = DateUtil.dateToStringTime(req.getFromPHYInfo().getJieguanShijian());
            cell = new PdfPCell(new Phrase(jieguanTime, chinesefont));
        }
        cell.setFixedHeight(FixedSize);
        cell.setColspan(2);
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("船公司", chinesefont));
        cell.setFixedHeight(FixedSize);
        table.addCell(cell);

        cell = new PdfPCell(new Phrase(req.getExtentionInfo().getBoatCompany(), chinesefont));
        cell.setFixedHeight(FixedSize);
        cell.setColspan(4);
        table.addCell(cell);

        //第十二行
        cell = new PdfPCell(new Phrase("提柜地点", chinesefont));
        cell.setFixedHeight(FixedSize);
        table.addCell(cell);

        cell = new PdfPCell(new Phrase(req.getFromPHYInfo().getTiguiAddress(), chinesefont));
        cell.setFixedHeight(FixedSize);
        cell.setColspan(2);
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("还柜地点", chinesefont));
        cell.setFixedHeight(FixedSize);
        table.addCell(cell);

        cell = new PdfPCell(new Phrase(req.getFromPHYInfo().getHaiguiAddress(), chinesefont));
        cell.setFixedHeight(FixedSize);
        cell.setColspan(4);
        table.addCell(cell);

        // 附加一行
        cell = new PdfPCell(new Phrase("提柜堆场", chinesefont));
        cell.setFixedHeight(FixedSize);
        table.addCell(cell);

        if (req.getFromPHYInfo().getTiguiDuichang()==null){
            cell = new PdfPCell(new Phrase("", chinesefont));
        }else {
            cell = new PdfPCell(new Phrase(req.getFromPHYInfo().getTiguiDuichang(), chinesefont));
        }
        cell.setFixedHeight(FixedSize);
        cell.setColspan(2);
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("还柜堆场", chinesefont));
        cell.setFixedHeight(FixedSize);
        table.addCell(cell);

        if (req.getFromPHYInfo().getHaiguiDuichang()==null){
            cell = new PdfPCell(new Phrase("", chinesefont));
        }else {
            cell = new PdfPCell(new Phrase(req.getFromPHYInfo().getHaiguiDuichang(), chinesefont));
        }
        cell.setFixedHeight(FixedSize);
        cell.setColspan(4);
        table.addCell(cell);

        //第十三行
        cell = new PdfPCell(new Phrase("注意事项", chinesefont));
        cell.setFixedHeight( FixedSize);
        cell.setColspan(8);
        table.addCell(cell);

        if (req.getBusinessInfo().getNote()==null){
            cell = new PdfPCell(new Phrase("", chinesefont));

        }else {
            cell = new PdfPCell(new Phrase(req.getBusinessInfo().getNote(), chinesefont));
        }
        cell.setColspan(8);
        cell.setFixedHeight(4* FixedSize);
        table.addCell(cell);

        //第十四行
        cell = new PdfPCell(new Phrase("常规备注", chinesefont));
        cell.setFixedHeight(FixedSize);
        cell.setColspan(8);
        table.addCell(cell);

        //第十五行
        cell = new PdfPCell(new Phrase("1.请准时到场,请提无异味及干净无破损的空柜(柜内不能有突出及横杠);\n2.司机不可与工厂发生冲突,不可在工厂内抽烟,不能穿拖/凉鞋及短裤进厂;\n3.请仔细阅读以上作业注意事项，并遵照执行; \n4.请司机离厂后立即还柜,并将相关资料以及费用及时进行申报。\n以上内容有误或要求变动，请立即通知客服，多谢配合!", chinesefont));
        cell.setFixedHeight(4 * FixedSize);
        cell.setColspan(8);
        table.addCell(cell);

        //第十六行
        cell = new PdfPCell(new Phrase("收发单位签名", chinesefont));
        cell.setFixedHeight(2 * FixedSize);
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("", chinesefont));
        cell.setFixedHeight(2 * FixedSize);
        cell.setColspan(2);
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("司机签名", chinesefont));
        cell.setFixedHeight(2 * FixedSize);
        table.addCell(cell);

        cell = new PdfPCell(new Phrase("", chinesefont));
        cell.setFixedHeight(2 * FixedSize);
        cell.setColspan(4);
        table.addCell(cell);

        //第十七行
        cell = new PdfPCell(new Phrase("此单证仅为我司内部作业文件，不做报关资料填写依据，报关资料请以船公司EIR文件为准。", chinesefont));
        cell.setFixedHeight(FixedSize);
        cell.setColspan(8);
        table.addCell(cell);

        /**************************工作线**********************************/

        document.add(table);
        document.close();

    }
}
