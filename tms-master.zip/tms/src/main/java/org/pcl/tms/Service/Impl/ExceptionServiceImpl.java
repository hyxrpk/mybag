package org.pcl.tms.Service.Impl;

import org.pcl.tms.Mapper.ExceptionsMapper;
import org.pcl.tms.Model.Exceptions;
import org.pcl.tms.Service.ExceptionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ExceptionServiceImpl implements ExceptionService {


    @Autowired
    private ExceptionsMapper eMapper;

    @Override
    public List<Exceptions> GetAll() {
        return eMapper.selectAll();
    }
}
