package org.pcl.tms.Model;

public class BoatCompany {
    private Integer id;

    private String bootName;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getBootName() {
        return bootName;
    }

    public void setBootName(String bootName) {
        this.bootName = bootName == null ? null : bootName.trim();
    }
}