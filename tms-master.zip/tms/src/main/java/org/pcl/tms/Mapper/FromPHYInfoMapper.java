package org.pcl.tms.Mapper;

import org.pcl.tms.Model.FromPHYInfo;

public interface FromPHYInfoMapper {
    int deleteByPrimaryKey(String id);

    int insert(FromPHYInfo record);

    int insertSelective(FromPHYInfo record);

    FromPHYInfo selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(FromPHYInfo record);

    int updateByPrimaryKey(FromPHYInfo record);
}