package org.pcl.tms.Service.Impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.pcl.tms.Controller.Request.Page;
import org.pcl.tms.Mapper.BoatCompanyMapper;
import org.pcl.tms.Model.BoatCompany;
import org.pcl.tms.Model.ContainerType;
import org.pcl.tms.Service.BoatService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BoatServiceImpl implements BoatService {

    @Autowired
    private BoatCompanyMapper bcMapper;

    @Override
    public PageInfo<BoatCompany> GetAll(Page req) {
        PageHelper.startPage(req.getPageNum(),req.getPageSize());
        List<BoatCompany> list = bcMapper.selectAll(req.getOrderBy(),req.getRule());
        PageInfo<BoatCompany> resp = new PageInfo<>(list);
        return resp;
    }
}
