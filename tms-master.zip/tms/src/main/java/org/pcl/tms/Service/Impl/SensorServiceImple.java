package org.pcl.tms.Service.Impl;

import org.pcl.tms.Mapper.SensorMapper;
import org.pcl.tms.Model.Sensor;
import org.pcl.tms.Service.SensorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SensorServiceImple implements SensorService {

    @Autowired
    private SensorMapper sMapper;

    @Override
    public int Insert(Sensor req) {
        int resp = sMapper.insertSelective(req);

        return resp;
    }
}
