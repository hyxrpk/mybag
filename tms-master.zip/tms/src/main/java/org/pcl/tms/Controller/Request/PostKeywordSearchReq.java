package org.pcl.tms.Controller.Request;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Setter
@Getter
public class PostKeywordSearchReq {

    private Page page;
    private String state;
    private String keyword;
}
