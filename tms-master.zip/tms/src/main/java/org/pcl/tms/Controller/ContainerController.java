package org.pcl.tms.Controller;

import lombok.extern.slf4j.Slf4j;
import org.pcl.tms.Controller.Request.Page;
import org.pcl.tms.Service.ContainerService;
import org.pcl.tms.Utils.ResponseVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@Slf4j
@RequestMapping("/container")
public class ContainerController {

    @Autowired
    private ContainerService cService;

    @PostMapping("all")
    public ResponseVo<?>GetAll(@RequestBody Page page){
        return ResponseVo.success(cService.selectAll(page));
    }


}
