package org.pcl.tms.Service;

import org.pcl.tms.Model.Factory;

public interface FactoryService {

    Factory Update(Factory req);

    Factory GetByID(int id);

    int DeleteById(int id);
}
