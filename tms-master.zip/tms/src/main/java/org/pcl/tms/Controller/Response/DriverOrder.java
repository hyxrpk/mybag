package org.pcl.tms.Controller.Response;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Data
@Getter
@Setter
public class DriverOrder {

    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    private Date yuyueDaochangTime;

    private String orderId;

//    private String orderId2;

    private float basicPayFee;

    private String payWay;

    private String tiguiAdd;

    private String zhuanghuoAdd;

//    private String zhuanghuoAdd2;

    private String xieguiAdd;

    private String note;

    private String container;

    private int type;

    private Float weight;

    private int isUrgent;

    private DriverOrder subOrder;
}
