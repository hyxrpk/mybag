package org.pcl.tms.Controller.Response;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Data
@Setter
@Getter
public class GetAllDriver {
    private int driverId;
    private String carNum;
    private String driverName;
    private float monthOutput;
    private int orderCount;
    private int workDay;
    private String currentLocation;
    private Date lastOrder;
    private String note;
}
