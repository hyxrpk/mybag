package org.pcl.tms.Controller;

import lombok.extern.slf4j.Slf4j;
import org.pcl.tms.Controller.Request.GetOrderReq;
import org.pcl.tms.Controller.Request.InsertOrderReq;
import org.pcl.tms.Controller.Response.IndexResp;
import org.pcl.tms.Mapper.OrderMapper;
import org.pcl.tms.Model.Order;
import org.pcl.tms.Service.OrderService;
import org.pcl.tms.Utils.CodeEnum;
import org.pcl.tms.Utils.ResponseVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@Slf4j
@RequestMapping("/order")
public class OrderController {

    @Autowired
    private OrderService oService;
    @Autowired
    private OrderMapper oMapper;
    @GetMapping("index")
    public ResponseVo<?> Index(){
        IndexResp resp = new IndexResp();
        resp.setDayOrderNum( oMapper.countToday());
        resp.setWeekOrderNum(oMapper.countWeek());
        resp.setMonthOrderNum(oMapper.countMonth());
        resp.setDaitijiaoNum(oMapper.count7dayByCondition(0));
        resp.setDaibandanNum(oMapper.count7dayByCondition(1));
        resp.setDairuNum(oMapper.count7dayByCondition(2));
        resp.setDaijihuaNum(oMapper.count7dayByCondition(3));
        return ResponseVo.success(resp);
    }

    @PostMapping("add")
    public ResponseVo<?> CreateOrder(@RequestBody InsertOrderReq req){
        Order isCreate = oService.CreateOrder(req);
        if (isCreate != null) {
            return ResponseVo.success(isCreate);
        } else {
            return ResponseVo.error(CodeEnum.insert_error, "创建失败");
        }
    }



    @PostMapping("update")
    public ResponseVo<?> UpdateOrder(@RequestBody InsertOrderReq req) {
        oService.UpdateOder(req);
        return ResponseVo.success();
    }

    @PostMapping("all")
    public ResponseVo<?> AllOrders(@RequestBody GetOrderReq req) {
        return ResponseVo.success(oService.ConditionSelect(req));
    }

    @PostMapping("list")
    public ResponseVo<?> OrdersByType(@RequestBody GetOrderReq req){
        return ResponseVo.success(oService.GetByType(req));
    }

    // 绑定司机 暂时貌似没用了
    @PostMapping("todriver")
    public ResponseVo<?> SendInfoToDriver(String orderId,int driverId) throws Exception {
        boolean flag = oService.SendInfoToDriver(orderId,driverId);
        if (flag) {
            return ResponseVo.success();
        }else {
            return ResponseVo.error();
        }
    }


    @PostMapping("delete")
    public ResponseVo<?> DeleteOrder(String id) {
        if(id!=""&&id!=null){
            oService.DeleteById(id);
            return ResponseVo.success();
        }
        return ResponseVo.error();
    }

    @GetMapping("so")
    public ResponseVo<?>GetBySo(String so){
        return ResponseVo.success(oService.GetBySo(so));
    }

    @GetMapping("one")
    public ResponseVo<?>GetOne(String orderId){
        return ResponseVo.success(oService.GetOneByID(orderId));
    }

    @PostMapping("bindFee")
    public ResponseVo<?> BindRecFee(String orderId){
        int res = oService.CopyContractToFee(orderId);
        if (res ==1){
        return ResponseVo.success();
        } else{
            return ResponseVo.error(CodeEnum.database_error);
        }
    }

    @PostMapping("matuo")
    public ResponseVo<?> BindMatuoOrder(@RequestParam(value="orderId1")String orderId1,
                                        @RequestParam(value="orderId2")String orderId2,
                                        @RequestParam(value="driverId",required=false, defaultValue="0")int driverId,
                                        @RequestParam(value="basicFee",required=false, defaultValue="0")Float basicFee,
                                        @RequestParam(value="state",required=false, defaultValue="0")int state){
        if (state==0) {
            int resp = oService.BindMatuoOrder(orderId1, orderId2);
            if (resp ==0){
                return ResponseVo.error(CodeEnum.database_error,"更新错误");
            }
        }else if(state==1){
            int resp =oService.BindMatuoOrderAndDriver(orderId1,orderId2,driverId,basicFee);
            if (resp ==0){
                return ResponseVo.error(CodeEnum.database_error,"更新错误");
            }
        }
        return ResponseVo.success();
    }

    @PostMapping("del")
    public ResponseVo<?> BatchDel(String ids){

        oService.DeleteOrders(ids);
        return ResponseVo.success();
    }

    @PostMapping("batchUp")
    public ResponseVo<?> BatchUpdate(String ids, int state){
        oService.BatchUpdate(ids,state);
        return ResponseVo.success();
    }

    @PostMapping("notifyCancel")
    public ResponseVo<?> NotifyDriverCancel(String orderId){
        boolean flag =oService.NotifyDriverCancel(orderId);
        if (flag=false){
                      return ResponseVo.error();
        }
        return ResponseVo.success();
    }

}

