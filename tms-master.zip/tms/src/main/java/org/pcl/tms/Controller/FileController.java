package org.pcl.tms.Controller;

import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;

import org.apache.commons.io.FileUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.pcl.tms.Controller.Request.IdRequest;
import org.pcl.tms.Controller.Request.InsertOrderReq;
import org.pcl.tms.Mapper.CustomMapper;
import org.pcl.tms.Model.Custom;
import org.pcl.tms.Model.Factory;
import org.pcl.tms.Model.Fee;
import org.pcl.tms.Service.OrderService;
import org.pcl.tms.Utils.Const;
import org.pcl.tms.Utils.DateUtil;
import org.pcl.tms.Utils.ExportExcelUtils;
import org.pcl.tms.Utils.ResponseVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.ResourceUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.pcl.tms.Utils.Const.headIndexOf;
import static org.pcl.tms.Utils.Const.serverURL;

@RestController
@Slf4j
@RequestMapping("/file")
public class FileController {

    @Autowired
    private OrderService oService;
    @Autowired
    private CustomMapper customMapper;

    @CrossOrigin(origins = "*", maxAge = 3600)
    @PostMapping("/save")
    public ResponseVo<?> UploadFile(MultipartFile file, String path, HttpServletRequest request) throws IOException {

        String basePath = ResourceUtils.getURL("classpath:").getPath();
        String filePath = basePath + "files/" + path + "/";
        File f = new File(filePath);
        if (!f.exists()) {
            f.mkdirs();
        }
        String fileName = filePath + file.getOriginalFilename();
        File uploadFile = new File(fileName);
        file.transferTo(uploadFile);
        return ResponseVo.success(Const.serverURL + "res" + path + "/" + file.getOriginalFilename()
//                http://localhost:8080/tms/res/client/suck.xlsx
//                "http://asa-cloud.com:10011/tms/res"+path+"/"+file.getOriginalFilename()
        );
    }

    @PostMapping("/excel")
    public ResponseVo<?> Excel(@RequestBody IdRequest ids, int type) throws Exception {
//        response.addHeader("Access-Control-Allow-Origin", "*");
        File file = ResourceUtils.getFile("classpath:templates/temp.xls");
        if (!file.exists()) {
            file.createNewFile();
        }
        OutputStream out = new FileOutputStream(file);
        if (type == 1) {
            String[] headers = {"NO.", "客户名", "工厂名称", "预约时间", "订舱号", "柜型", "柜号", "柜重(KG)", "封条号", "车牌", "司机", "电话", "客户名称", "客户委托号", "客户联系人", "船名", "航次", "截关时间", "报关方式", "还柜地", "备注"};
            List<List<String>> data = new ArrayList<List<String>>();
            //导出司机资料
            for (String id : ids.getIds()) {
                InsertOrderReq one = oService.GetOneByID(id);
                List rowData = new ArrayList();
                rowData.add(one.getOrder().getId());
                rowData.add(one.getClient().getClientName());
                String factoryName = "";
                for (Factory f : one.getExtentionInfo().getFactorys()) {
                    factoryName = factoryName + "\r" + f.getFactoryName();
                }

                rowData.add(factoryName);
                rowData.add(DateUtil.dateToStringTime(one.getBusinessInfo().getYuyueDaochangTime()));
                rowData.add(one.getBusinessInfo().getSoNum());
                rowData.add(one.getExtentionInfo().getContainer());
                rowData.add(one.getDriverOrderInfo().getContainerNum());
                if (one.getDriverOrderInfo().getContainerWeight() != null) {
                    rowData.add(one.getDriverOrderInfo().getContainerWeight().toString());
                } else {
                    rowData.add("");
                }
                rowData.add(one.getDriverOrderInfo().getSealNum());
                rowData.add(one.getExtentionInfo().getCarNum());
                rowData.add(one.getExtentionInfo().getDriver().getDriverName());
                rowData.add(one.getExtentionInfo().getDriver().getDriverPhone());
                rowData.add(one.getClient().getClientName());
                rowData.add(one.getBusinessInfo().getClientOrderNum());
                rowData.add(one.getClient().getClientContact());
                rowData.add(one.getFromPHYInfo().getBoatName());
                rowData.add(one.getFromPHYInfo().getHangci());
                if (one.getFromPHYInfo().getJieguanShijian() != null) {
                    rowData.add(DateUtil.dateToStringTime(one.getFromPHYInfo().getJieguanShijian()));
                } else {
                    rowData.add("");
                }
                Custom custom = customMapper.selectByPrimaryKey(one.getBusinessInfo().getCustomTypeId());
                rowData.add(custom.getCustom());
                rowData.add(one.getFromPHYInfo().getHaiguiAddress());
                rowData.add(one.getBusinessInfo().getNote());
                data.add(rowData);
            }
            ExportExcelUtils eeu = new ExportExcelUtils();
            HSSFWorkbook workbook = new HSSFWorkbook();
            eeu.exportExcel(workbook, 0, "司机资料", headers, data, out);
            //原理就是将所有的数据一起写入，然后再关闭输入流。
            workbook.write(out);
            out.close();
        } else if (type == 2) {
            // 渡柜订单补料信息
            String[] headers = {"NO.", "客户名称", "工厂名称", "订舱号", "柜型", "柜号", "封条号", "客户委托号", "柜重(KG)"};
            List<List<String>> data = new ArrayList<List<String>>();
            //导出司机资料
            for (String id : ids.getIds()) {
                InsertOrderReq one = oService.GetOneByID(id);
                List rowData = new ArrayList();
                rowData.add(one.getOrder().getId());
                rowData.add(one.getClient().getClientName());
                String factoryName = "";
                for (Factory f : one.getExtentionInfo().getFactorys()) {
                    factoryName = factoryName + "\r" + f.getFactoryName();
                }
                rowData.add(factoryName);
                rowData.add(one.getBusinessInfo().getSoNum());
                rowData.add(one.getExtentionInfo().getContainer());
                rowData.add(one.getDriverOrderInfo().getContainerNum());
                rowData.add(one.getDriverOrderInfo().getSealNum());
                rowData.add(one.getBusinessInfo().getClientOrderNum());
                if (one.getDriverOrderInfo().getContainerWeight() != null) {
                    rowData.add(one.getDriverOrderInfo().getContainerWeight().toString());
                } else {
                    rowData.add("");
                }
                data.add(rowData);
            }
            ExportExcelUtils eeu = new ExportExcelUtils();
            HSSFWorkbook workbook = new HSSFWorkbook();
            eeu.exportExcel(workbook, 0, "渡柜订单补料信息", headers, data, out);
            //原理就是将所有的数据一起写入，然后再关闭输入流。
            workbook.write(out);
            out.close();
        } else if (type == 3) {
            // 费用明细
            String[] headers = {"订单号", "客户名称", "业务类型", "预约到厂时间", "S/O号", "渡柜时间", "渡柜堆场", "装卸货工厂", "提柜地","还柜地", "柜型", "关联孖拖订单号", "货重", "报关方式", "到厂时间", "离厂时间", "车牌号", "司机姓名", "应付总额", "应收总额", "差额", "审核状态"};
            String[] headers1 = {"订单号", "客户名称", "业务类型", "预约到厂时间", "S/O号", "渡柜时间", "渡柜堆场", "装卸货工厂", "提柜地","还柜地", "柜型", "关联孖拖订单号", "货重", "报关方式", "到厂时间", "离厂时间", "车牌号", "司机姓名", "应收费用名称", "金额", "税点", "币种", "结算方式"};
            String[] headers2 = {"订单号", "客户名称", "业务类型", "预约到厂时间", "S/O号", "渡柜时间", "渡柜堆场", "装卸货工厂", "提柜地", "还柜地","柜型", "关联孖拖订单号", "货重", "报关方式", "到厂时间", "离厂时间", "车牌号", "司机姓名", "应付费用名称", "金额", "结算单位", "结算方式"};
            List<List<String>> data = new ArrayList<List<String>>();
            List<List<String>> data1 = new ArrayList<List<String>>();
            List<List<String>> data2 = new ArrayList<List<String>>();
            //导出司机资料
            for (String id : ids.getIds()) {
                InsertOrderReq one = oService.GetOneByID(id);
                List rowData = new ArrayList();
                rowData.add(one.getOrder().getId());
                rowData.add(one.getClient().getClientName());
                int orderType = one.getBusinessInfo().getOrderType();
                String yewuleixing ="";
                if (orderType==1){
                    yewuleixing="出口";
                }else if (orderType==2){
                    yewuleixing="进口";
                }else if (orderType==3){
                    yewuleixing="渡柜";
                }
                rowData.add(yewuleixing);
                rowData.add(DateUtil.dateToStringTime(one.getBusinessInfo().getYuyueDaochangTime()));
                rowData.add(one.getBusinessInfo().getSoNum());

                if (one.getOrder().getDuguiTime() != null) {
                    rowData.add(DateUtil.dateToStringTime(one.getOrder().getDuguiTime()));
                } else {
                    rowData.add("");
                }

                if (one.getOrder().getDuguiduichangAddress() != null) {
                    rowData.add(one.getOrder().getDuguiduichangAddress());
                } else {
                    rowData.add("");
                }

                String factoryName = "";
                for (Factory f : one.getExtentionInfo().getFactorys()) {
                    factoryName = factoryName + "\r" + f.getFactoryName();
                }
                rowData.add(factoryName);
                rowData.add(one.getFromPHYInfo().getTiguiAddress());
                rowData.add(one.getFromPHYInfo().getHaiguiAddress());
                rowData.add(one.getExtentionInfo().getContainer());
                rowData.add(one.getOrder().getDoubleRelatedOrder());
                rowData.add(one.getBusinessInfo().getOrderWeight().toString());
                Custom custom = customMapper.selectByPrimaryKey(one.getBusinessInfo().getCustomTypeId());
                rowData.add(custom.getCustom());
                rowData.add("?");
                rowData.add("?");
                rowData.add(one.getExtentionInfo().getCarNum());
                rowData.add(one.getExtentionInfo().getDriver().getDriverName());
                rowData.add(one.getPayFee().getTotalPrice().toString());
                rowData.add(one.getReceiveFee().getTotalPrice().toString());

                Float chae = one.getReceiveFee().getTotalPrice() - one.getPayFee().getTotalPrice();
                rowData.add(chae.toString());

                if (one.getReceiveFee().getIsAudit() == 1) {
                    rowData.add("是");
                } else {
                    rowData.add("否");
                }
                data.add(rowData);
                List rowData1 = new ArrayList();
                rowData1.add(one.getOrder().getId());
                rowData1.add(one.getClient().getClientName());
                rowData1.add(yewuleixing);
                rowData1.add(DateUtil.dateToStringTime(one.getBusinessInfo().getYuyueDaochangTime()));
                rowData1.add(one.getBusinessInfo().getSoNum());
                if (one.getOrder().getDuguiTime() != null) {
                    rowData1.add(DateUtil.dateToStringTime(one.getOrder().getDuguiTime()));
                } else {
                    rowData1.add("");
                }

                if (one.getOrder().getDuguiduichangAddress() != null) {
                    rowData1.add(one.getOrder().getDuguiduichangAddress());
                } else {
                    rowData1.add("");
                }

                String factoryName1 = "";
                for (Factory f : one.getExtentionInfo().getFactorys()) {
                    factoryName1 = factoryName1 + "\r" + f.getFactoryName();
                }
                rowData1.add(factoryName1);
                rowData1.add(one.getFromPHYInfo().getTiguiAddress());
                rowData1.add(one.getFromPHYInfo().getHaiguiAddress());
                rowData1.add(one.getExtentionInfo().getContainer());
                rowData1.add(one.getOrder().getDoubleRelatedOrder());
                rowData1.add(one.getBusinessInfo().getOrderWeight().toString());
                Custom custom1 = customMapper.selectByPrimaryKey(one.getBusinessInfo().getCustomTypeId());
                rowData1.add(custom1.getCustom());
                rowData1.add("?");
                rowData1.add("?");
                rowData1.add(one.getExtentionInfo().getCarNum());
                rowData1.add(one.getExtentionInfo().getDriver().getDriverName());
                String RecFeeName = "";
                String recFeeList = one.getReceiveFee().getFeeList();
                List<Fee> RecArray = JSONObject.parseArray(recFeeList, Fee.class);
                for (Fee recF: RecArray){
                    if (recF.getPrice()!=0){
                        RecFeeName= RecFeeName+"\r"+recF.getFeeName();
                    }
                }

                rowData1.add(RecFeeName);
                rowData1.add(one.getReceiveFee().getTotalPrice().toString());
                rowData1.add(one.getReceiveFee().getTax());
                rowData1.add(one.getReceiveFee().getCurrency());
                rowData1.add(one.getReceiveFee().getPayWay());
                data1.add(rowData1);

                List rowData2 = new ArrayList();
                rowData2.add(one.getOrder().getId());
                rowData2.add(one.getClient().getClientName());
                rowData2.add(yewuleixing);
                rowData2.add(DateUtil.dateToStringTime(one.getBusinessInfo().getYuyueDaochangTime()));
                rowData2.add(one.getBusinessInfo().getSoNum());

                if (one.getOrder().getDuguiTime() != null) {
                    rowData2.add(DateUtil.dateToStringTime(one.getOrder().getDuguiTime()));
                } else {
                    rowData2.add("");
                }

                if (one.getOrder().getDuguiduichangAddress() != null) {
                    rowData2.add(one.getOrder().getDuguiduichangAddress());
                } else {
                    rowData2.add("");
                }

                String factoryName2 = "";
                for (Factory f : one.getExtentionInfo().getFactorys()) {
                    factoryName2 = factoryName2 + "\r" + f.getFactoryName();
                }
                rowData2.add(factoryName2);
                rowData2.add(one.getFromPHYInfo().getTiguiAddress());
                rowData2.add(one.getFromPHYInfo().getHaiguiAddress());
                rowData2.add(one.getExtentionInfo().getContainer());
                rowData2.add(one.getOrder().getDoubleRelatedOrder());
                rowData2.add(one.getBusinessInfo().getOrderWeight().toString());
                Custom custom2 = customMapper.selectByPrimaryKey(one.getBusinessInfo().getCustomTypeId());
                rowData2.add(custom2.getCustom());
                rowData2.add("?");
                rowData2.add("?");
                rowData2.add(one.getExtentionInfo().getCarNum());
                rowData2.add(one.getExtentionInfo().getDriver().getDriverName());

                String PayFeeName = "";
                String payFeeList = one.getPayFee().getFeeList();
                List<Fee> payArray = JSONObject.parseArray(payFeeList, Fee.class);
                for (Fee payF: payArray){
                    if (payF.getPrice()!=0){
                        PayFeeName= PayFeeName+"\r"+payF.getFeeName();
                    }
                }

                rowData2.add(PayFeeName);
                rowData2.add(one.getPayFee().getTotalPrice().toString());
                rowData2.add(one.getPayFee().getCurrency());
                rowData2.add(one.getPayFee().getPayWay());
                data2.add(rowData2);
            }
            ExportExcelUtils eeu = new ExportExcelUtils();
            HSSFWorkbook workbook = new HSSFWorkbook();

            eeu.exportExcel(workbook, 0, "费用明细", headers, data, out);
            eeu.exportExcel(workbook, 1, "应收明细", headers1, data1, out);
            eeu.exportExcel(workbook, 2, "应付明细", headers2, data2, out);
            //原理就是将所有的数据一起写入，然后再关闭输入流。
            workbook.write(out);
            out.close();
        }
        String basePath = ResourceUtils.getURL("classpath:").getPath();
        File destFile = new File(basePath + "files/download" + "/" + System.currentTimeMillis()+".xls");
        FileUtils.copyFile(file, destFile);
        String downloadPath = serverURL+"res/download/"+destFile.getName();
        return ResponseVo.success(downloadPath);

    }

    @GetMapping("/export/{userName}/{fileName}")
    public void DownloadFile(@PathVariable String userName, @PathVariable String fileName, HttpServletRequest request, HttpServletResponse response) {
        // 文件路径需要配置
        String basePath = "/home/";
        String filePath = basePath + "files/" + userName;
        String fName = filePath + "/" + fileName;
        File f = new File(fName);
        if (f.exists()) {
            breakpoint(response, fileName, f, request);
        }
    }


    public void breakpoint(HttpServletResponse mResponse, String fileName, File file, HttpServletRequest request) {
        mResponse.reset();
        mResponse.addHeader("Access-Control-Allow-Origin", "*");
        mResponse.setCharacterEncoding("utf-8");
        mResponse.setContentType("application/x-download");
        mResponse.setHeader("Accept-Ranges", "bytes");
//		mResponse.setHeader("Connection", "keep-alive");
        mResponse.setContentLengthLong(file.length());
        try {
            mResponse.addHeader("Content-Disposition", "attachment;fileName=" + URLEncoder.encode(fileName, "UTF-8"));
        } catch (UnsupportedEncodingException e1) {
            e1.printStackTrace();
        }
        FileInputStream in = null;
        ServletOutputStream out = null;
        long pos = 0;
        if (null != request.getHeader("Range")) {
            // 断点续传
            mResponse.setStatus(HttpServletResponse.SC_PARTIAL_CONTENT);
            try {
                pos = Long.parseLong(request.getHeader("Range").replaceAll("bytes=", "").replaceAll("-", ""));
            } catch (NumberFormatException e) {
                pos = 0;
            }
        }
        try {
            in = new FileInputStream(file.getPath());
            out = mResponse.getOutputStream();
            in.skip(pos);
            byte[] buffer = new byte[1024 * 10];
            int length = 0;
            while ((length = in.read(buffer, 0, buffer.length)) != -1) {
                out.write(buffer, 0, length);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (out != null) {
                try {
                    out.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
