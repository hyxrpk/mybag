package org.pcl.tms.Controller.Response;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.pcl.tms.Model.User;

@Setter
@Getter
@Data
public class UserLoginResp {
    User user;
    String token;
}
