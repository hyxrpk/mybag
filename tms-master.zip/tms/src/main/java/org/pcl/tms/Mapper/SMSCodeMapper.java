package org.pcl.tms.Mapper;

import org.apache.ibatis.annotations.Param;
import org.pcl.tms.Model.SMSCode;

public interface SMSCodeMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(SMSCode record);

    int insertSelective(SMSCode record);

    SMSCode selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(SMSCode record);

    int updateByPrimaryKey(SMSCode record);

    SMSCode selectLatestCode(@Param("phone") String phone);
}