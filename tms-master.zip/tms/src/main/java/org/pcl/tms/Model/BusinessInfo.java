package org.pcl.tms.Model;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.util.Date;

public class BusinessInfo {
    private String id;

    private String relatedOrderId;

    private Integer orderType;

    private String soNum;

    private Integer boatCompanyId;

    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    private Date yuyueDaochangTime;
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    private Date earliestTiguiTime;
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    private Date latestTiguiTime;
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    private Date latestHuanguiTime;

    private Float orderWeight;

    private Integer containerTypeId;

    private String containerPosition;

    private Integer isDouble;

    private Integer isWeighing;

    private Integer weighingTypeId;

    private Integer customTypeId;

    private String clientOrderNum;

    private String carryDoc;

    private String note;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getRelatedOrderId() {
        return relatedOrderId;
    }

    public void setRelatedOrderId(String relatedOrderId) {
        this.relatedOrderId = relatedOrderId == null ? null : relatedOrderId.trim();
    }

    public Integer getOrderType() {
        return orderType;
    }

    public void setOrderType(Integer orderType) {
        this.orderType = orderType;
    }

    public String getSoNum() {
        return soNum;
    }

    public void setSoNum(String soNum) {
        this.soNum = soNum == null ? null : soNum.trim();
    }

    public Integer getBoatCompanyId() {
        return boatCompanyId;
    }

    public void setBoatCompanyId(Integer boatCompanyId) {
        this.boatCompanyId = boatCompanyId;
    }

    public Date getYuyueDaochangTime() {
        return yuyueDaochangTime;
    }

    public void setYuyueDaochangTime(Date yuyueDaochangTime) {
        this.yuyueDaochangTime = yuyueDaochangTime;
    }

    public Date getEarliestTiguiTime() {
        return earliestTiguiTime;
    }

    public void setEarliestTiguiTime(Date earliestTiguiTime) {
        this.earliestTiguiTime = earliestTiguiTime;
    }

    public Date getLatestTiguiTime() {
        return latestTiguiTime;
    }

    public void setLatestTiguiTime(Date latestTiguiTime) {
        this.latestTiguiTime = latestTiguiTime;
    }

    public Date getLatestHuanguiTime() {
        return latestHuanguiTime;
    }

    public void setLatestHuanguiTime(Date latestHuanguiTime) {
        this.latestHuanguiTime = latestHuanguiTime;
    }

    public Float getOrderWeight() {
        return orderWeight;
    }

    public void setOrderWeight(Float orderWeight) {
        this.orderWeight = orderWeight;
    }

    public Integer getContainerTypeId() {
        return containerTypeId;
    }

    public void setContainerTypeId(Integer containerTypeId) {
        this.containerTypeId = containerTypeId;
    }

    public String getContainerPosition() {
        return containerPosition;
    }

    public void setContainerPosition(String containerPosition) {
        this.containerPosition = containerPosition == null ? null : containerPosition.trim();
    }

    public Integer getIsDouble() {
        return isDouble;
    }

    public void setIsDouble(Integer isDouble) {
        this.isDouble = isDouble;
    }

    public Integer getIsWeighing() {
        return isWeighing;
    }

    public void setIsWeighing(Integer isWeighing) {
        this.isWeighing = isWeighing;
    }

    public Integer getWeighingTypeId() {
        return weighingTypeId;
    }

    public void setWeighingTypeId(Integer weighingTypeId) {
        this.weighingTypeId = weighingTypeId;
    }

    public Integer getCustomTypeId() {
        return customTypeId;
    }

    public void setCustomTypeId(Integer customTypeId) {
        this.customTypeId = customTypeId;
    }

    public String getClientOrderNum() {
        return clientOrderNum;
    }

    public void setClientOrderNum(String clientOrderNum) {
        this.clientOrderNum = clientOrderNum == null ? null : clientOrderNum.trim();
    }

    public String getCarryDoc() {
        return carryDoc;
    }

    public void setCarryDoc(String carryDoc) {
        this.carryDoc = carryDoc == null ? null : carryDoc.trim();
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note == null ? null : note.trim();
    }

    @Override
    public String toString() {
        return "BusinessInfo{" +
                "id='" + id + '\'' +
                ", relatedOrderId='" + relatedOrderId + '\'' +
                ", orderType=" + orderType +
                ", soNum='" + soNum + '\'' +
                ", boatCompanyId=" + boatCompanyId +
                ", yuyueDaochangTime=" + yuyueDaochangTime +
                ", earliestTiguiTime=" + earliestTiguiTime +
                ", latestTiguiTime=" + latestTiguiTime +
                ", latestHuanguiTime=" + latestHuanguiTime +
                ", orderWeight=" + orderWeight +
                ", containerTypeId=" + containerTypeId +
                ", containerPosition='" + containerPosition + '\'' +
                ", isDouble=" + isDouble +
                ", isWeighing=" + isWeighing +
                ", weighingTypeId=" + weighingTypeId +
                ", customTypeId=" + customTypeId +
                ", clientOrderNum='" + clientOrderNum + '\'' +
                ", carryDoc='" + carryDoc + '\'' +
                ", note='" + note + '\'' +
                '}';
    }
}