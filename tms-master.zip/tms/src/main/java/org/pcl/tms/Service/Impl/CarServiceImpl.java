package org.pcl.tms.Service.Impl;

import org.pcl.tms.Mapper.CarMapper;
import org.pcl.tms.Model.Car;
import org.pcl.tms.Service.CarService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CarServiceImpl implements CarService {

    @Autowired
    private CarMapper carMapper;

    @Override
    public Car GetByID(int id) {

        return carMapper.selectByPrimaryKey(id);
    }
}
