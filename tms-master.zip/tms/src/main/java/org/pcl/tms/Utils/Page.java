package org.pcl.tms.Utils;

public class Page {

    public static boolean isHasNext(int total, int pageSize,int pageNum){
        int currentStartRow = pageSize*(pageNum-1);
        int currentEndRow = pageSize*pageNum;
        if (currentEndRow<total){
            return true;
        }else if (currentEndRow >= total){
            return false;
        }
        return false;
    }

    public static int StartRow( int pageSize,int pageNum){
        int currentStartRow = pageSize*(pageNum-1);
        return currentStartRow;
    }

    public static int EndRow(int total, int pageSize,int pageNum ){
        int currentEndRow = pageSize*pageNum;
        if (currentEndRow<total){
            return currentEndRow;
        }else if (currentEndRow >= total){
            return total;
        }
        return 0;
    }
}
