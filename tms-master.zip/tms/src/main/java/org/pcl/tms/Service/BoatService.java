package org.pcl.tms.Service;

import com.github.pagehelper.PageInfo;
import org.pcl.tms.Controller.Request.Page;
import org.pcl.tms.Model.BoatCompany;

public interface BoatService {

    PageInfo<BoatCompany> GetAll(Page page);
}
