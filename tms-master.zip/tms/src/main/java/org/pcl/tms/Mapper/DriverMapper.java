package org.pcl.tms.Mapper;

import org.apache.ibatis.annotations.Param;
import org.pcl.tms.Model.Driver;

import java.util.List;

public interface DriverMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(Driver record);

    int insertSelective(Driver record);

    Driver selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(Driver record);

    int updateByPrimaryKey(Driver record);

    List<Driver> selectAllByStatus();

    Driver selectByAccountAndPwd(Driver record);

    Driver selectByNameAndIDCard(Driver record);

    List<Driver>selectAll();

    List<Driver> availableDrvier();

    int countAll();
//    --  select count(*) from driver where is_valid =1 and status=1 and reg_id is not null
//    select * from (select * from orders where process_status=4 and  driver_order_id = ANY(select id from driver_order_info where driver_id = ANY(select id from driver where is_valid =1 and status=1 and reg_id is not null))) table2
}