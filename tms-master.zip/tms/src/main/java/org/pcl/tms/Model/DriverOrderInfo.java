package org.pcl.tms.Model;

public class DriverOrderInfo {
    private String id;

    private Integer driverId;

    private String containerNumUrl;

    private String containerNum;

    private Float containerWeight;

    private String sealNum;

    private String sealNumUrl;

    private String sealPhotoUrl;

    private String zuoyehuidanUrl;

    private String clientWeituohuidanUrl;

    private String weighingFeeUrl;

    private String highSpeedFeeUrl;

    private Integer isAccept;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public Integer getDriverId() {
        return driverId;
    }

    public void setDriverId(Integer driverId) {
        this.driverId = driverId;
    }

    public String getContainerNumUrl() {
        return containerNumUrl;
    }

    public void setContainerNumUrl(String containerNumUrl) {
        this.containerNumUrl = containerNumUrl == null ? null : containerNumUrl.trim();
    }

    public String getContainerNum() {
        return containerNum;
    }

    public void setContainerNum(String containerNum) {
        this.containerNum = containerNum == null ? null : containerNum.trim();
    }

    public Float getContainerWeight() {
        return containerWeight;
    }

    public void setContainerWeight(Float containerWeight) {
        this.containerWeight = containerWeight;
    }

    public String getSealNum() {
        return sealNum;
    }

    public void setSealNum(String sealNum) {
        this.sealNum = sealNum == null ? null : sealNum.trim();
    }

    public String getSealNumUrl() {
        return sealNumUrl;
    }

    public void setSealNumUrl(String sealNumUrl) {
        this.sealNumUrl = sealNumUrl == null ? null : sealNumUrl.trim();
    }

    public String getSealPhotoUrl() {
        return sealPhotoUrl;
    }

    public void setSealPhotoUrl(String sealPhotoUrl) {
        this.sealPhotoUrl = sealPhotoUrl == null ? null : sealPhotoUrl.trim();
    }

    public String getZuoyehuidanUrl() {
        return zuoyehuidanUrl;
    }

    public void setZuoyehuidanUrl(String zuoyehuidanUrl) {
        this.zuoyehuidanUrl = zuoyehuidanUrl == null ? null : zuoyehuidanUrl.trim();
    }

    public String getClientWeituohuidanUrl() {
        return clientWeituohuidanUrl;
    }

    public void setClientWeituohuidanUrl(String clientWeituohuidanUrl) {
        this.clientWeituohuidanUrl = clientWeituohuidanUrl == null ? null : clientWeituohuidanUrl.trim();
    }

    public String getWeighingFeeUrl() {
        return weighingFeeUrl;
    }

    public void setWeighingFeeUrl(String weighingFeeUrl) {
        this.weighingFeeUrl = weighingFeeUrl == null ? null : weighingFeeUrl.trim();
    }

    public String getHighSpeedFeeUrl() {
        return highSpeedFeeUrl;
    }

    public void setHighSpeedFeeUrl(String highSpeedFeeUrl) {
        this.highSpeedFeeUrl = highSpeedFeeUrl == null ? null : highSpeedFeeUrl.trim();
    }

    public Integer getIsAccept() {
        return isAccept;
    }

    public void setIsAccept(Integer isAccept) {
        this.isAccept = isAccept;
    }
}