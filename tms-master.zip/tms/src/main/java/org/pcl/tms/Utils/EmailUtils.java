package org.pcl.tms.Utils;

import org.apache.ibatis.annotations.ConstructorArgs;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.File;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Address;
import javax.mail.Authenticator;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.Message.RecipientType;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
@Component
public class EmailUtils {


    //FIXME: springboot无法将配置文件值加载到静态变量中 通过set方法注入
    private static String account;
    private static String password;

    @Value("${email.account}")
    public void setAccount(String account) {
        EmailUtils.account = account;
    }
    @Value("${email.password}")
    public void setPassword(  String password) {
        EmailUtils.password = password;
    }

    public static void Send(String toAddress, String subject, Object object) throws MessagingException {
//        System.out.println(account);
//        System.out.println(password);
        Properties props = new Properties();
        //发送邮件的服务器
        props.setProperty("mail.smtp.host", "smtp.163.com");
        //发送邮件的协议
        props.setProperty("mail.transport.protocol", "smtp");
        //在连接服务器的时候是否需要验证，发邮件是需要验证的
        props.setProperty("mail.smtp.auth", "true");
        Authenticator authenticator = new Authenticator() {

            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                // TODO Auto-generated method stub
//                return new PasswordAuthentication("zhangian0405@163.com", "zhangyan199245");
                return new PasswordAuthentication(account,password);
            }

        };

        Session session = Session.getInstance(props, authenticator);
        //设为true，可以看到发送邮件的整个过程
        session.setDebug(false);
        //利用配好配置信息的Session新建一封邮件
        Message message = new MimeMessage(session);
        //设置邮件的发送者
        message.setFrom(new InternetAddress("zhangian0405@163.com"));

        message.setSubject(subject);
        Address[] recipients = InternetAddress.parse(toAddress);
        //收邮件的人,如果有抄送，密送的，可以类似的设置，只是把RecipientType改为相应的类型
        message.setRecipients(RecipientType.TO, recipients);
        message.setContent(object.toString(),"text/html;charset=utf-8");
        Transport.send(message);//发送
    }

    public static void main(String args[]) throws AddressException, MessagingException {
        EmailUtils emailUtils = new EmailUtils();
        emailUtils.Send("zhangyanforwork@gmail.com","司机信息推送", "asdf");
//        Properties props = new Properties();
        //发送邮件的服务器
//        props.setProperty("mail.smtp.host", "smtp.163.com");
        //发送邮件的协议
//        props.setProperty("mail.transport.protocol", "smtp");
        //在连接服务器的时候是否需要验证，发邮件是需要验证的
//        props.setProperty("mail.smtp.auth", "true");
        //用户名
//        final String username = "zhangian0405@163.com";
        //密码
//        final String password = "zhangyan199245";

        //利用上述的用户名和密码构造一个Authenticator对象，并把它给Session，
        //当需要进行验证的时候，会自动从Session中去取该Authenticator对象
//        Authenticator authenticator = new Authenticator() {
//
//            @Override
//            protected PasswordAuthentication getPasswordAuthentication() {
                // TODO Auto-generated method stub
//                return new PasswordAuthentication(username, password);
//            }

//        };
        //利用上述提供给系统的属性和Authenticator构造一个Session对象
//        Session session = Session.getInstance(props, authenticator);
        //设为true，可以看到发送邮件的整个过程
//        session.setDebug(true);
        //利用配好配置信息的Session新建一封邮件
//        Message message = new MimeMessage(session);
        //设置邮件的发送者
//        message.setFrom(new InternetAddress("zhangian0405@163.com"));
//        邮件的主题
//        message.setSubject("司机信息推送");
//        Address[] recipients = InternetAddress.parse("798567300@qq.com");
        //收邮件的人,如果有抄送，密送的，可以类似的设置，只是把RecipientType改为相应的类型
//        message.setRecipients(RecipientType.TO, recipients);
//        BodyPart part1 = new MimeBodyPart();
//        BodyPart part2 = new MimeBodyPart();
//        BodyPart part3 = new MimeBodyPart();
//        BodyPart part4 = new MimeBodyPart();
//        BodyPart part5 = new MimeBodyPart();
//        设置内容为html
//        part1.setContent("Dear Dr.Wu and Prof.Ying, \n this is ian, I am really glad to see u guys, hope our idea will inspire u", "text/html;charset=utf-8");
//        设置内容为普通文本
//        part2.setText("你好，Part2");
//        将一个bodyPart加到最前面
//        part3.setText("Hello Part3");


//        /**
//         * 发送一个附件的情况
//         */
//        //设置附件
//        //DataSource是对附件的封装,是一个接口，系统已经实现的子类有URLDataSource, DataHandlerDataSource, FileDataSource
//        //里面封装了各种与附件有关的方法，包括获取附件的InputStream
//        DataSource dataSource = new FileDataSource(new File("/Users/ian/Desktop/ibm_cn_zh_chaincodes.pdf"));
//        //DataHandler是对DataSource的封装，可以把Stream转换为String，
//        DataHandler dataHandler = new DataHandler(dataSource);
//        part4.setDataHandler(dataHandler);
//        //附件的名称，默认为content，如果文件名不加扩展名在进行附件下载的时候系统会不知道该附件是什么类型的附件，
//        //这样在不清楚文件类型的情况下，文件有可能是打不开的
//        part4.setFileName("doc.sql");

        /**
         * 发送多个附件的情况
         */
//        Multipart attachments = new MimeMultipart();
//        BodyPart attach1 = new MimeBodyPart();
//        //设置附件1的内容
//        DataSource dataSource_attach1 = new FileDataSource(new File("/Users/ian/Desktop/ibm_cn_zh_chaincodes.pdf"));
//        DataHandler dataHandler_attach1 = new DataHandler(dataSource_attach1);
//        attach1.setDataHandler(dataHandler_attach1);
//        attach1.setFileName("attach1_doc.sql");
//        BodyPart attach2 = new MimeBodyPart();
//        //设置附件2的内容
//        DataSource dataSource_attach2 = new FileDataSource(new File("/Users/ian/Desktop/ibm_cn_zh_chaincodes.pdf"));
//        DataHandler dataHandler_attach2 = new DataHandler(dataSource_attach2);
//        attach2.setDataHandler(dataHandler_attach2);
//        attach2.setFileName("attach2_doc.sql");
//        attachments.addBodyPart(attach1);
//        attachments.addBodyPart(attach2);
//        part5.setContent(attachments);
//
//        Multipart multipart = new MimeMultipart();
//        multipart.addBodyPart(part1);
//        multipart.addBodyPart(part2);
//        multipart.addBodyPart(part3,0);
//        multipart.addBodyPart(part4);
//        multipart.addBodyPart(part5);
//        message.setContent(multipart);
//        Transport.send(message);//发送

    }

}
