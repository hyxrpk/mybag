package org.pcl.tms.Service.Impl;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.apache.commons.io.FileUtils;
import org.pcl.tms.Controller.Request.*;
import org.pcl.tms.Controller.Response.DriverOrder;
//import org.pcl.tms.Controller.Response.GetDriverOrderResp;
import org.pcl.tms.Mapper.*;
import org.pcl.tms.Model.*;
import org.pcl.tms.Service.OrderService;
import org.pcl.tms.Utils.*;
import org.pcl.tms.Utils.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderMapper oMapper;
    @Autowired
    private BusinessInfoMapper bMapper;
    @Autowired
    private FollowUpInfoMapper fuiMapper;
    @Autowired
    private FromPHYInfoMapper fphyMapper;
    @Autowired
    private DriverOrderInfoMapper doinfoMapper;
    @Autowired
    private DriverMapper dMapper;
    @Autowired
    private ClientMapper cMapper;
    @Autowired
    private FeesMapper fMapper;
    @Autowired
    private ContractMapper contractMapper;
    @Autowired
    private FactoryMapper factoryMapper;

    @Autowired
    private ContainerTypeMapper ctMapper;

    @Autowired
    private BoatCompanyMapper bcMapper;

    @Autowired
    private CarMapper carMapper;

    public int MAX(int[] arr) {
        Arrays.sort(arr);
        return arr[arr.length - 1];
    }

    @Override
    synchronized public Order CreateOrder(InsertOrderReq req) {
        //插入业务信息
        BusinessInfo b = new BusinessInfo();
        BeanUtils2.copyProperties(req.getBusinessInfo(), b);
        b.setId(UUIDGenerator.getUUID());
        int isBusyCreate = bMapper.insertSelective(b);

        FollowUpInfo fuinfo = new FollowUpInfo();
        fuinfo.setId(UUIDGenerator.getUUID());
        int isFuiCreate = fuiMapper.insertSelective(fuinfo);
        int isFphyCreate= 0;

        FromPHYInfo fphyinfo = new FromPHYInfo();
        if (req.getFromPHYInfo()!=null){
            fphyinfo = req.getFromPHYInfo();
            fphyinfo.setId(UUIDGenerator.getUUID());
            isFphyCreate =fphyMapper.insertSelective(fphyinfo);
        }else {
            fphyinfo.setId(UUIDGenerator.getUUID());
             isFphyCreate = fphyMapper.insertSelective(fphyinfo);
        }
        DriverOrderInfo doinfo = new DriverOrderInfo();
        if (req.getDriverOrderInfo() != null) {
            BeanUtils2.copyProperties(req.getDriverOrderInfo(), doinfo);
        }
        doinfo.setId(UUIDGenerator.getUUID());
        int isDoiCreate = doinfoMapper.insertSelective(doinfo);

        if (isBusyCreate == 0 && isFuiCreate == 0 && isFphyCreate == 0 && isDoiCreate == 0) {
            return null;
        } else {
            // 生成流水号
            List<Order> orders = oMapper.CountCurrentDay();
            int num = 0;
            if (orders.size() != 0) {
                int[] arr = new int[orders.size()];
                for (int i = 0; i < orders.size(); i++) {
                    int id = Integer.parseInt(orders.get(i).getId().substring(10, 14));
                    arr[i] = id;
                }
                num = MAX(arr);
            }
            Date now = new Date();
            String DateStr = DateUtil.dateTimeToString(now);
            String id = "ST" + DateStr + String.format("%04d", num + 1);
            // 创建订单
            Order o = new Order();
            BeanUtils2.copyProperties(req.getOrder(), o);
            o.setId(id);
            o.setFollowUpId(fuinfo.getId());
            o.setBusinessInfoId(b.getId());
            o.setFromPhyId(fphyinfo.getId());
            o.setDriverOrderId(doinfo.getId());
            int isOrderCreate = oMapper.insertSelective(o);
            String feeList = "[{\"feeName\": \"吊柜费\",\"price\": \"0\",\"feeUrl\": \"\",\"feeObject\": \"\",\"isDefault\": 1}, {\"feeName\": \"过磅费\",\"price\": \"0\",\"feeUrl\": \"\",\"feeObject\": \"\",\"isDefault\": 1}, {\"feeName\": \"停车费\",\"price\": \"0\",\"feeUrl\": \"\",\"feeObject\": \"\",\"isDefault\": 1}, {\"feeName\": \"高速费\",\"price\": \"0\",\"feeUrl\": \"\",\"isDefault\": 1}]";
            Fees fee1 = new Fees();
            Fees fee2 = new Fees();
            fee1.setOrderId(o.getId());
            fee2.setOrderId(o.getId());
            fee1.setFeeList(feeList);
            fee2.setFeeList(feeList);
            fee1.setType(1);
            fee2.setType(2);

            int isFee1Create = fMapper.insertSelective(fee1);
            int isFee2Create = fMapper.insertSelective(fee2);
            if (isOrderCreate == 0 && isFee1Create == 0 && isFee2Create == 0) {
                return null;
            } else {
                return o;
            }
        }
    }


    @Override
    public PageInfo<InsertOrderReq> ConditionSelect(GetOrderReq req) {
        // 异常订单列表
        if (req.getState() == 8) {
//            int total = fuiMapper.selectExceptionOrder(req.getPage().getOrderBy(), req.getPage().getRule()).size();
            PageHelper.startPage(req.getPage().getPageNum(), req.getPage().getPageSize());
            List<Order> orders = fuiMapper.selectExceptionOrder(req.getPage().getOrderBy(), req.getPage().getRule());
            List<InsertOrderReq> resp = new ArrayList<>();
            for (Order one : orders) {
                InsertOrderReq res = GetOneByID(one.getId());
                resp.add(res);
            }
            PageInfo<InsertOrderReq> result = new PageInfo<>(resp);
            int count = fuiMapper.countExceptionOrder();
            result.setTotal(count);
            result.setHasNextPage(Page.isHasNext(count,req.getPage().getPageSize(),req.getPage().getPageNum()));
            return result;
        } else if (req.getState() == 7) {
            PageHelper.startPage(req.getPage().getPageNum(), req.getPage().getPageSize());
            List<Order> orders = oMapper.selectAll(req.getPage().getOrderBy(), req.getPage().getRule(),req.getType());
            List<InsertOrderReq> resp = new ArrayList<>();
            for (Order one : orders) {
                InsertOrderReq res = GetOneByID(one.getId());
                resp.add(res);
            }
            PageInfo<InsertOrderReq> result = new PageInfo<>(resp);
            int count = oMapper.countAllOrders(req.getType());
            result.setTotal(count);
            result.setHasNextPage(Page.isHasNext(count,req.getPage().getPageSize(),req.getPage().getPageNum()));
            return result;
        } else {
            PageHelper.startPage(req.getPage().getPageNum(), req.getPage().getPageSize());
            List<Order> orders = oMapper.selectByCondition(req.getState(), req.getPage().getOrderBy(), req.getPage().getRule(),req.getType());
            List<InsertOrderReq> resp = new ArrayList<>();
            for (Order one : orders) {
                InsertOrderReq res = GetOneByID(one.getId());
                resp.add(res);
            }
            PageInfo<InsertOrderReq> result = new PageInfo<>(resp);
            int count = oMapper.countByCondition(req.getState(),req.getType());
            result.setTotal(count);
            result.setHasNextPage(Page.isHasNext(count,req.getPage().getPageSize(),req.getPage().getPageNum()));
            return result;
        }
    }

    @Override
    public void UpdateOder(InsertOrderReq req) {
        Order o = req.getOrder();
        BusinessInfo businfo = req.getBusinessInfo();
        FollowUpInfo fuinfo = req.getFollowUpInfo();
        FromPHYInfo fphyinfo = req.getFromPHYInfo();
        DriverOrderInfo doinfo = req.getDriverOrderInfo();
        Fees payFee = req.getPayFee();
        Fees receiveFee = req.getReceiveFee();
        if (o != null) {
            if (o.getDoubleRelatedOrder()!=null&&o.getDoubleRelatedOrder().equals("-1")){
                oMapper.updateByPrimaryKeySelective(o);
                int orderSuc= oMapper.unbindOrder(o);
            }else{
            int orderSuc = oMapper.updateByPrimaryKeySelective(o);
            }
        }
        if (businfo != null) {
            int busySuc = bMapper.updateByPrimaryKeySelective(businfo);
        }
        if (fuinfo != null) {
            int fuiSuc = fuiMapper.updateByPrimaryKeySelective(fuinfo);
        }
        if (fphyinfo != null) {
            int fphySuc = fphyMapper.updateByPrimaryKeySelective(fphyinfo);
        }
        if (doinfo != null) {
            if (doinfo.getDriverId()==null ||doinfo.getDriverId()!=-1){
            int doiSuc = doinfoMapper.updateByPrimaryKeySelective(doinfo);
            }else if (doinfo.getDriverId()==-1){
                NotifyDriverCancel(req.getOrder().getId());
                int doiSuc = doinfoMapper.cancelDriver(doinfo);
            }
        }

        if (payFee != null) {
            int payfeeSuc = fMapper.updateByPrimaryKeySelective(payFee);
        }
        if (receiveFee != null) {
            int recfeeSuc = fMapper.updateByPrimaryKeySelective(receiveFee);
        }
        // TODO: 确定发送邮件的时间节点
    }

    // 发送信息给司机
    @Override
    public boolean SendInfoToDriver(String orderId, int driverId) throws Exception {
        Driver d = dMapper.selectByPrimaryKey(driverId);
        if (d == null) {
            return false;
        }
        JPush.Push(d.getRegId(), "你有新的订单");

        // bindDriverFee
        InsertOrderReq one = GetOneByID(orderId);
        Fees payFee = one.getPayFee();
        payFee.setPayWay(d.getPayWay());

        // 生成作业单
        File file = ResourceUtils.getFile("classpath:templates/temp.pdf");
        String basePath = ResourceUtils.getURL("classpath:").getPath();
        InsertOrderReq req = GetOneByID(orderId);
        PDFUtil pdf = new PDFUtil();
        pdf.CreatePDF(file.getPath(), req);
        File destFile = new File(basePath + "files/orders/" + orderId + "/" + "worksheet.pdf");
        FileUtils.copyFile(file, destFile);
        String worksheetPath = Const.serverURL + "res/orders/" + orderId + "/worksheet.pdf";
        req.getFollowUpInfo().setWorksheetUrl(worksheetPath);
        fuiMapper.updateByPrimaryKeySelective(req.getFollowUpInfo());
        return true;
    }

    // TODO: 发送邮件给客户
    @Override
    public void SendInfoToClient(InsertOrderReq req) {
        int clientID = req.getOrder().getClientId();
        int driverID = req.getDriverOrderInfo().getDriverId();
        Client client = cMapper.selectByPrimaryKey(clientID);
        Driver driver = dMapper.selectByPrimaryKey(driverID);
    }

    @Override
    public void DeleteById(String id) {
        InsertOrderReq order = GetOneByID(id);
        oMapper.deleteByPrimaryKey(id);
        bMapper.deleteByPrimaryKey(order.getOrder().getBusinessInfoId());
        fuiMapper.deleteByPrimaryKey(order.getOrder().getFollowUpId());
        fphyMapper.deleteByPrimaryKey(order.getOrder().getFromPhyId());
        doinfoMapper.deleteByPrimaryKey(order.getOrder().getDriverOrderId());
        fMapper.deleteByPrimaryKey(order.getPayFee().getId());
        fMapper.deleteByPrimaryKey(order.getReceiveFee().getId());
        //TODO: 删除费用
    }


    //    @Override
//    public GetDriverOrderResp GetOrderByDriverID(GetDriverOrderReq req) {
//        PageHelper.startPage(req.getPage().getPageNum(),req.getPage().getPageSize());
//        List<Order> orders = doinfoMapper.GetOrderByDriverID(req.getDriverId(),req.getPage().getRule(),req.getPage().getOrderBy());
//        List<DriverOrder> finishedList = new ArrayList<>();
//        List<DriverOrder> unfinishedList = new ArrayList<>();
//        System.out.println(orders.size());
//        for (Order o:orders){
//            InsertOrderReq one = GetOneByID(o.getId());
//
//            if (one.getOrder().getProcessStatus()==5){
//                DriverOrder res = TransferOrderToDriverOrder(one);
//                finishedList.add(res);
//            }else {
//                DriverOrder res = TransferOrderToDriverOrder(one);
//                unfinishedList.add(res);
//            }
//        }
//        GetDriverOrderResp resp = new GetDriverOrderResp();
//        PageInfo<DriverOrder> lists = new PageInfo<>(finishedList);
//        //TODO: 判断订单状态分别加入finish 和 unfinish
//        resp.setFinished(lists);
//        resp.setUnfinished(unfinishedList);
//        return resp;
//    }
    @Override
    public PageInfo<DriverOrder> DriverUnfinishedOrder(GetDriverOrderReq req) {
        PageHelper.startPage(req.getPage().getPageNum(), req.getPage().getPageSize());
        List<Order> orders = doinfoMapper.GetOrderByDriverID(req.getDriverId(), req.getPage().getRule(), req.getPage().getOrderBy());
        List<DriverOrder> driverOrders = new ArrayList<>();
        for (Order o : orders) {
            // 已完成订单的状态为6
            InsertOrderReq one = GetOneByID(o.getId());
            if (one.getOrder().getProcessStatus() >= 6) {
                continue;
            } else if (one.getOrder().getProcessStatus() == 5) {
                DriverOrder resp = TransferOrderToDriverOrder(one);
                if (one.getOrder().getDoubleRelatedOrder() != null && !one.getOrder().getDoubleRelatedOrder().equals("")) {
                    InsertOrderReq subOrder = GetOneByID(one.getOrder().getDoubleRelatedOrder());
                    resp.setSubOrder(TransferOrderToDriverOrder(subOrder));
                }
                driverOrders.add(resp);
            }
        }
        for (int i = 0; i < driverOrders.size(); i++) {
            for (int j = 1; j < driverOrders.size(); j++) {
                if (driverOrders.get(i).getSubOrder() != null && !driverOrders.get(i).getSubOrder().equals("")) {
                    if (driverOrders.get(i).getSubOrder().getOrderId().equals(driverOrders.get(j).getOrderId())) {
                        driverOrders.remove(driverOrders.get(j));
                    }
                }
            }
        }
        PageInfo<DriverOrder> res = new PageInfo<>(driverOrders);
        return res;
    }

    @Override
    public PageInfo<DriverOrder> DrvierFinishedOrder(GetDriverOrderReq req) {
        PageHelper.startPage(req.getPage().getPageNum(), req.getPage().getPageSize());
        List<Order> orders = doinfoMapper.GetOrderByDriverID(req.getDriverId(), req.getPage().getRule(), req.getPage().getOrderBy());
        List<DriverOrder> driverOrders = new ArrayList<>();
        System.out.println(orders.size());
        for (Order o : orders) {
            // 已完成订单的状态为6
            InsertOrderReq one = GetOneByID(o.getId());
            if (one.getOrder().getProcessStatus() < 6) {
                continue;
            } else {
                DriverOrder resp = TransferOrderToDriverOrder(one);
                if (one.getOrder().getDoubleRelatedOrder() != null && !one.getOrder().getDoubleRelatedOrder().equals("")) {
                    InsertOrderReq subOrder = GetOneByID(one.getOrder().getDoubleRelatedOrder());
                    resp.setSubOrder(TransferOrderToDriverOrder(subOrder));
                }
                driverOrders.add(resp);
            }
        }
        for (int i = 0; i < driverOrders.size(); i++) {
            for (int j = 1; j < driverOrders.size(); j++) {
                if (driverOrders.get(i).getSubOrder() != null && !driverOrders.get(i).getSubOrder().equals("")) {
                    if (driverOrders.get(i).getSubOrder().getOrderId().equals(driverOrders.get(j).getOrderId())) {
                        driverOrders.remove(driverOrders.get(j));
                    }
                }
            }
        }
        PageInfo<DriverOrder> res = new PageInfo<>(driverOrders);
        List<Order> forcount = doinfoMapper.GetOrderByDriverIDAndStatus(6,req.getDriverId());
        double count =0;
        for (Order one: forcount){
            if (one.getDoubleRelatedOrder()==null){
                count= count+1;
            }else {
                count=count+0.5;
            }
        }
        res.setTotal((long) count);
        res.setHasNextPage(Page.isHasNext((int) count,req.getPage().getPageSize(),req.getPage().getPageNum()));
        return res;
    }

    @Override
    public InsertOrderReq BindDriverAndOrder(String orderId, int driverId, float basicFee) throws Exception {
        InsertOrderReq one = GetOneByID(orderId);
        DriverOrderInfo driverOrderInfo = one.getDriverOrderInfo();
        Order order = one.getOrder();
        order.setProcessStatus(order.getProcessStatus() + 1);
        int res = oMapper.updateByPrimaryKeySelective(order);
        driverOrderInfo.setDriverId(driverId);
        doinfoMapper.updateByPrimaryKeySelective(driverOrderInfo);
        Fees payFee = one.getPayFee();
        payFee.setBasicFee(basicFee);
        fMapper.updateByPrimaryKeySelective(payFee);
        boolean flag = SendInfoToDriver(orderId, driverId);
        return one;
    }

    @Override
    public int AcceptOrder(AcceptOrderReq req) {

        if (req.getOrders().length != 0) {
            for (String param : req.getOrders()) {
                InsertOrderReq one = GetOneByID(param);
                if (one.getOrder().getProcessStatus() != 4||one.getDriverOrderInfo().getDriverId()!=req.getDriverId()) {
                    return -1;
                }
                Order o = one.getOrder();
                o.setProcessStatus(o.getProcessStatus() + 1);
                int isoSuc = oMapper.updateByPrimaryKeySelective(one.getOrder());

                DriverOrderInfo doinfo = one.getDriverOrderInfo();
                doinfo.setDriverId(req.getDriverId());
                doinfo.setIsAccept(1);
                int isDoiSuc = doinfoMapper.updateByPrimaryKeySelective(doinfo);
                if (isDoiSuc != 1 && isoSuc != 1) {
                    return 0;
                }
            }
            return 1;
        }
        return 0;// 参数错误
    }

    @Override
    public PageInfo<InsertOrderReq> GetByType(GetOrderReq req) {
        PageHelper.startPage(req.getPage().getPageNum(), req.getPage().getPageSize());
        List<Order> orders = oMapper.selectByType(req.getState(),req.getPage().getOrderBy(),req.getPage().getRule());
        List<InsertOrderReq> res = new ArrayList<>();
        for (Order one : orders) {
            InsertOrderReq o = GetOneByID(one.getId());
            res.add(o);
        }
        PageInfo<InsertOrderReq> resp = new PageInfo<>(res);
        int count  = oMapper.countByType(req.getState());
        resp.setTotal(count);
        resp.setHasNextPage(Page.isHasNext(count,req.getPage().getPageSize(),req.getPage().getPageNum()));
        return resp;
    }

    @Override
    public int BindMatuoOrder(String order1, String order2) {
        Order o = new Order();
        o.setId(order1);
        o.setDoubleRelatedOrder(order2);
        int res1 = oMapper.updateByPrimaryKeySelective(o);
        o.setId(order2);
        o.setDoubleRelatedOrder(order1);
        int res2 = oMapper.updateByPrimaryKeySelective(o);
        if (res1 == 0 || res2 == 0) {
            return 0;
        }
        return 1;
    }

    @Override
    public int BindMatuoOrderAndDriver(String orderId1, String orderId2, int driverid, float basicFee) {
        // 绑定第一个订单
        InsertOrderReq one = GetOneByID(orderId1);
        DriverOrderInfo driverOrderInfo = one.getDriverOrderInfo();
        Order firstOrder = one.getOrder();
        firstOrder.setProcessStatus(firstOrder.getProcessStatus() + 1);
        firstOrder.setDoubleRelatedOrder(orderId2);
        int isSuc = oMapper.updateByPrimaryKeySelective(firstOrder);
        if (isSuc == 0) {
            return isSuc;
        }
        driverOrderInfo.setDriverId(driverid);
        int resp1 = doinfoMapper.updateByPrimaryKeySelective(driverOrderInfo);
        if (resp1 == 0) {
            return resp1;
        }
        Fees payFee = one.getPayFee();
        payFee.setBasicFee(basicFee);
        int resp2 = fMapper.updateByPrimaryKeySelective(payFee);
        if (resp2 == 0) {
            return resp2;
        }
        // 绑定第二个订单
        InsertOrderReq second = GetOneByID(orderId2);
        DriverOrderInfo secDriverOrderInfo = second.getDriverOrderInfo();
        Order secOrder = second.getOrder();
        secOrder.setDoubleRelatedOrder(orderId1);
        secOrder.setProcessStatus(secOrder.getProcessStatus() + 1);
        int isSuc1 = oMapper.updateByPrimaryKeySelective(secOrder);
        if (isSuc1 == 0) {
            return isSuc;
        }
        secDriverOrderInfo.setDriverId(driverid);
        int resp3 = doinfoMapper.updateByPrimaryKeySelective(secDriverOrderInfo);
        if (resp3 == 0) {
            return resp3;
        }
        Driver d = dMapper.selectByPrimaryKey(driverid);
        if (d == null) {
            return 0;
        }
        JPush.Push(d.getRegId(), "新的matuo订单");
        return 1;
    }

    @Override
    public void CascadeDelete(String orderId) {
        Order one = oMapper.selectByPrimaryKey(orderId);
        bMapper.deleteByPrimaryKey(one.getBusinessInfoId());
        doinfoMapper.deleteByPrimaryKey(one.getDriverOrderId());
        fuiMapper.deleteByPrimaryKey(one.getFollowUpId());
        fphyMapper.deleteByPrimaryKey(one.getFromPhyId());
        fMapper.deleteByOrderId(orderId);
        oMapper.deleteByPrimaryKey(orderId);
        if (one.getDoubleRelatedOrder() != null) {
            Order second = oMapper.selectByPrimaryKey(orderId);
            bMapper.deleteByPrimaryKey(second.getBusinessInfoId());
            doinfoMapper.deleteByPrimaryKey(second.getDriverOrderId());
            fuiMapper.deleteByPrimaryKey(second.getFollowUpId());
            fphyMapper.deleteByPrimaryKey(second.getFromPhyId());
            fMapper.deleteByOrderId(second.getId());
            oMapper.deleteByPrimaryKey(second.getId());
        }
    }

    @Override
    public void DeleteOrders(String orders) {
        if (orders.contains(",")) {
            String[] ids = orders.split(",");
            for (String id : ids) {
                CascadeDelete(id);
            }
        } else {
            CascadeDelete(orders);
        }
    }

    @Override
    public void BatchUpdate(String orders, int state) {
        if (orders.contains(",")) {
            String[] ids = orders.split(",");
            for (String id : ids) {
                Order one = oMapper.selectByPrimaryKey(id);
                one.setProcessStatus(state);
                oMapper.updateByPrimaryKeySelective(one);
                if (one.getDoubleRelatedOrder() != null) {
                    Order second = oMapper.selectByPrimaryKey(one.getDoubleRelatedOrder());
                    second.setProcessStatus(state);
                    oMapper.updateByPrimaryKeySelective(second);
                }
            }
        } else {
            Order one = oMapper.selectByPrimaryKey(orders);
            one.setProcessStatus(state);
            oMapper.updateByPrimaryKeySelective(one);
            if (one.getDoubleRelatedOrder() != null) {
                Order second = oMapper.selectByPrimaryKey(one.getDoubleRelatedOrder());
                second.setProcessStatus(state);
                oMapper.updateByPrimaryKeySelective(second);
            }
        }
    }

    @Override
    public void GeneratePDF(String path, InsertOrderReq req) {

    }

    @Override
    public PageInfo<InsertOrderReq> Feelist(GetOrderReq req) {
        List<Order> orders = oMapper.selectFeeOrders(req.getPage().getOrderBy(), req.getPage().getRule());
        List<InsertOrderReq> resp = new ArrayList<>();
        for (Order o : orders) {
            InsertOrderReq one = GetOneByID(o.getId());
            // 更新应收
            String RecFees = one.getReceiveFee().getFeeList();
            List<Fee> RecArray = JSONObject.parseArray(RecFees, Fee.class);
            Float RecTotalExtraFee = 0.0f;
            for (Fee f : RecArray) {
                RecTotalExtraFee = f.getPrice() + RecTotalExtraFee;
            }
            one.getReceiveFee().setTotalExtraFee(RecTotalExtraFee);
            one.getReceiveFee().setTotalPrice(RecTotalExtraFee + one.getReceiveFee().getBasicFee());
            fMapper.updateByPrimaryKeySelective(one.getReceiveFee());
            // 更新应付
            String PayFees = one.getPayFee().getFeeList();
            List<Fee> PayArray = JSONObject.parseArray(PayFees, Fee.class);
            Float PayTotalExtraFee = 0.0f;
            for (Fee f : PayArray) {
                PayTotalExtraFee = f.getPrice() + PayTotalExtraFee;
            }
            one.getPayFee().setTotalExtraFee(PayTotalExtraFee);
            one.getPayFee().setTotalPrice(PayTotalExtraFee + one.getPayFee().getBasicFee());
            fMapper.updateByPrimaryKeySelective(one.getPayFee());
            resp.add(one);
        }
        List<InsertOrderReq> result = new ArrayList<>();
        result = resp.subList(
                Page.StartRow(req.getPage().getPageSize(),req.getPage().getPageNum()),
                Page.EndRow(resp.size(),req.getPage().getPageSize(),req.getPage().getPageNum())
                );
//        PageHelper.startPage(req.getPage().getPageNum(), req.getPage().getPageSize());
        PageInfo<InsertOrderReq> res = new PageInfo<>(result);
        res.setTotal(orders.size());
        res.setHasNextPage(Page.isHasNext(result.size(),req.getPage().getPageSize(),req.getPage().getPageNum()));
        return res;
    }

    @Override
    public boolean NotifyDriverCancel(String orderID) {
        InsertOrderReq one = GetOneByID(orderID);
        Driver d = dMapper.selectByPrimaryKey(one.getDriverOrderInfo().getDriverId());
        if (d == null) {
            return false;
        }
        JPush.Push(d.getRegId(), "你的订单已被取消");
        return true;
    }

    public DriverOrder TransferOrderToDriverOrder(InsertOrderReq one) {
        DriverOrder res = new DriverOrder();
        res.setYuyueDaochangTime(one.getBusinessInfo().getYuyueDaochangTime());
        res.setOrderId(one.getOrder().getId());
        res.setNote(one.getBusinessInfo().getNote());
        res.setBasicPayFee(one.getPayFee().getBasicFee());
        ContainerType container = ctMapper.selectByPrimaryKey(one.getBusinessInfo().getContainerTypeId());
        res.setContainer(container.getContainerName());
        Driver driver = dMapper.selectByPrimaryKey(one.getDriverOrderInfo().getDriverId());
        res.setPayWay(driver.getPayWay());
        res.setTiguiAdd(one.getFromPHYInfo().getTiguiAddress());
        res.setType(one.getBusinessInfo().getOrderType());
        res.setWeight(one.getBusinessInfo().getOrderWeight());
        res.setXieguiAdd(one.getFromPHYInfo().getHaiguiAddress());
        String factoryIds = one.getOrder().getFactoryId();
        String[] firstIds = factoryIds.split(",");
        if (one.getBusinessInfo().getNote().contains("赶")) {
            res.setIsUrgent(1);
        } else {
            res.setIsUrgent(0);
        }
        Factory f = factoryMapper.selectByPrimaryKey(Integer.valueOf(firstIds[0]));
        res.setZhuanghuoAdd(f.getFactoryDistrict() + f.getFactoryStreet());
        return res;
    }

    @Override
    public InsertOrderReq GetOneByID(String id) {
        InsertOrderReq resp = new InsertOrderReq();
        Order o = oMapper.selectByPrimaryKey(id);
        resp.setOrder(o);
        resp.setBusinessInfo(bMapper.selectByPrimaryKey(o.getBusinessInfoId()));
        resp.setDriverOrderInfo(doinfoMapper.selectByPrimaryKey(o.getDriverOrderId()));
        resp.setFollowUpInfo(fuiMapper.selectByPrimaryKey(o.getFollowUpId()));
        resp.setFromPHYInfo(fphyMapper.selectByPrimaryKey(o.getFromPhyId()));
        Fees fee = new Fees();
        fee.setOrderId(o.getId());
        List<Fees> fees = fMapper.getByOrder(fee);
        for (Fees f : fees) {
            if (f.getType() == 2) {
                resp.setPayFee(f);
            } else if (f.getType() == 1) {
                resp.setReceiveFee(f);
            }
        }
        resp.setClient(cMapper.selectByPrimaryKey(o.getClientId()));
        ExtentionInfo eInfo = new ExtentionInfo();
        List<Factory> factories = new ArrayList<>();
        if (!o.getFactoryId().contains(",") && !o.getFactoryId().equals("") && o.getFactoryId() != null) {
            Factory f = factoryMapper.selectByPrimaryKey(Integer.valueOf(o.getFactoryId()));
            factories.add(f);
        } else if (o.getFactoryId().contains(",")) {
            String[] ids = o.getFactoryId().split(",");
            for (String a : ids) {
                if (!a.equals("") && a != null) {
                    Factory f = factoryMapper.selectByPrimaryKey(Integer.valueOf(a));
                    factories.add(f);
                }
            }
        }
        eInfo.setFactorys(factories);
        ContainerType ct = ctMapper.selectByPrimaryKey(resp.getBusinessInfo().getContainerTypeId());
        eInfo.setContainer(ct.getContainerName());
        eInfo.setBoatCompany(bcMapper.selectByPrimaryKey(resp.getBusinessInfo().getBoatCompanyId()).getBootName());
//        System.out.println(resp.getOrder().getId());
        if (resp.getDriverOrderInfo().getDriverId() != null && resp.getDriverOrderInfo().getDriverId() != 0) {
            Driver d = dMapper.selectByPrimaryKey(resp.getDriverOrderInfo().getDriverId());
            Car car = carMapper.selectByPrimaryKey(d.getCarId());
            eInfo.setCarNum(car.getCarNum());
            eInfo.setPayWay(d.getPayWay());
        }
        if (resp.getBusinessInfo().getNote().contains("急")) {
            eInfo.setIsUrgent(1);
        }
        //TODO: 放在配置文件里
        eInfo.setContactNum("4006560303");
        if (resp.getDriverOrderInfo().getDriverId() != null) {
            eInfo.setDriver(dMapper.selectByPrimaryKey(resp.getDriverOrderInfo().getDriverId()));
        }
        resp.setExtentionInfo(eInfo);
        return resp;
    }

    @Override
    public PageInfo<DriverOrder> GetUnacceptOrder(int driverId) {
        List<DriverOrderInfo> doinfos = doinfoMapper.GetByDriverID(driverId);
        List<InsertOrderReq> resp = new ArrayList<>();
        List<DriverOrder> driverOrders = new ArrayList<>();
        for (DriverOrderInfo doi : doinfos) {
            Order o = oMapper.selectByDriverOrderID(doi.getId());
            if (o.getProcessStatus() == 4) {
                InsertOrderReq one = GetOneByID(o.getId());
                resp.add(one);
            }
        }
        for (InsertOrderReq one : resp) {
            DriverOrder dOrder = TransferOrderToDriverOrder(one);
            if (one.getOrder().getDoubleRelatedOrder() != null && !one.getOrder().getDoubleRelatedOrder().equals("")) {
                InsertOrderReq subOrder = GetOneByID(one.getOrder().getDoubleRelatedOrder());
                dOrder.setSubOrder(TransferOrderToDriverOrder(subOrder));
            }
            driverOrders.add(dOrder);
        }
        for (int i = 0; i < driverOrders.size(); i++) {
            for (int j = 1; j < driverOrders.size(); j++) {
                if (driverOrders.get(i).getSubOrder() != null && !driverOrders.get(i).getSubOrder().equals("")) {
                    if (driverOrders.get(i).getSubOrder().getOrderId().equals(driverOrders.get(j).getOrderId())) {
                        driverOrders.remove(driverOrders.get(j));
                    }
                }
            }
        }
        PageInfo<DriverOrder> res = new PageInfo<>(driverOrders);
        return res;
    }

    @Override
    public List<InsertOrderReq> GetBySo(String so) {
        List<BusinessInfo> binfo = bMapper.selectBySo(so);
        List<InsertOrderReq> resp = new ArrayList<>();
        for (BusinessInfo b : binfo) {
            List<Order> orders = oMapper.selectBybinfo(b.getId());
            for (Order o : orders) {
                InsertOrderReq res = GetOneByID(o.getId());
                resp.add(res);
            }
        }
        return resp;
    }


    // 出口还柜地为准 进口提柜地 渡柜没有
    @Override
    public int CopyContractToFee(String orderID) {
        InsertOrderReq order = GetOneByID(orderID);
        List<Contract> contract = contractMapper.selectByClientId(order.getClient().getId());
        String feeInfo = contract.get(0).getFeeInfo();

        JSONArray json = JSONArray.parseArray(feeInfo);
        String basicFee = null;
        if (json.size() != 0) {
            JSONObject one = JSONObject.parseObject(String.valueOf(json.get(0)));
            if (order.getBusinessInfo().getOrderType() == 1) {
                String huaigui = order.getFromPHYInfo().getHaiguiAddress();
                String key = matchAdd(huaigui);
                basicFee = (String) one.get(key);
            } else if (order.getBusinessInfo().getOrderType() == 2) {
                String tigui = order.getFromPHYInfo().getTiguiAddress();
                String key = matchAdd(tigui);
                basicFee = (String) one.get(key);
            }
            order.getReceiveFee().setBasicFee(Float.valueOf(basicFee));
            order.getReceiveFee().setContractId(contract.get(0).getId());
            order.getReceiveFee().setCurrency(contract.get(0).getCurrency());
            order.getReceiveFee().setPayWay(contract.get(0).getPayWay());
            order.getReceiveFee().setTax(contract.get(0).getTax());
            int isFeeSuc = fMapper.updateByPrimaryKeySelective(order.getReceiveFee());
            return isFeeSuc;
        }
        return 0;
    }

    String matchAdd(String add) {
        if (add.contains("盐田")) {
            return "yantian";
        } else if (add.contains("蛇口")) {
            return "shekou";
        } else if (add.contains("大铲湾")) {
            return "dachanwan";
        } else {
            return null;
        }
    }

}
