package org.pcl.tms.Controller.Response;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.HashMap;

@Data
@Setter
@Getter
public class IndexResp {
    private int dayOrderNum;
    private int weekOrderNum;
    private int monthOrderNum;
    private int daitijiaoNum;
    private int daibandanNum;
    private int dairuNum;
    private int daijihuaNum;
}
