package org.pcl.tms.Service.Impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.apache.poi.ss.formula.functions.T;
import org.pcl.tms.Controller.Request.InsertClientReq;
import org.pcl.tms.Controller.Request.Page;
import org.pcl.tms.Controller.Request.PostKeywordSearchReq;
import org.pcl.tms.Mapper.ClientMapper;
import org.pcl.tms.Mapper.ContractMapper;
import org.pcl.tms.Mapper.FactoryMapper;
import org.pcl.tms.Model.Client;
import org.pcl.tms.Model.Contract;
import org.pcl.tms.Model.Factory;
import org.pcl.tms.Service.ClientService;
import org.pcl.tms.Utils.BeanUtils2;
import org.pcl.tms.Utils.PageBean;
import org.pcl.tms.Utils.ReadExcelUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.List;
import java.util.Map;

@Service
public class ClientServiceImpl implements ClientService {

    @Autowired
    private ClientMapper cMapper;

    @Autowired
    private FactoryMapper fMapper;

    @Autowired
    private ContractMapper contractMapper;

    @Override
    public void InsertFromExcel(String path) throws Exception {
        ReadExcelUtil excelReader = new ReadExcelUtil(path);
        // 对读取Excel表格内容测试
        Map<Integer, Map<Integer, Object>> map = excelReader.readExcelContent();
//        System.out.println("获得Excel表格的内容:");
        for (int i = 1; i <= map.size(); i++) {
            Map<Integer, Object> row = map.get(i);
            Client c = new Client();
            c.setClientName((String) row.get(0));
            c.setClientAddress((String) row.get(1));
            c.setClientContact((String) row.get(2));
            String num =row.get(3).toString();
            DecimalFormat df = new DecimalFormat("#");
            BigDecimal bg=new BigDecimal(num);
            c.setClientPhone(bg.toPlainString());
            c.setClientEmail((String) row.get(4));
            List<Client> list = cMapper.selectByName(c.getClientName());
            if (list.size()==0){
                cMapper.insertSelective(c);
            }
            List<Client> isCreate = cMapper.selectByName(c.getClientName());
            if(isCreate.size()!=0) {
                Factory f = new Factory();
                f.setClientId(isCreate.get(0).getId());
                f.setFactoryName((String) row.get(5));
                f.setFactoryProvince((String) row.get(6));
                f.setFactoryCity((String) row.get(7));
                f.setFactoryDistrict((String) row.get(8));
                f.setFactoryStreet((String) row.get(9));
                f.setFactoryAddress((String) row.get(10));
                f.setFactoryContact((String) row.get(11));
                String facNum = row.get(12).toString();
                BigDecimal facbg = new BigDecimal(facNum);
                f.setFactoryPhone(facbg.toPlainString());
                Double defaultDb = Double.valueOf(String.valueOf(row.get(13)));
                int a = (int) Math.ceil(defaultDb);
                f.setIsDefault(a);
                fMapper.insertSelective(f);
            }
        }
    }

    @Override
    public void AddClient(InsertClientReq req) {
        Client c = new Client();
        BeanUtils2.copyProperties(req.getClient(),c);
        List<Client> isExistClient = cMapper.selectByName(c.getClientName());
        if(isExistClient.size()==0){
            cMapper.insertSelective(c);
        }
        List<Client> isCreate =cMapper.selectByName(c.getClientName());
        for (int i =0;i<req.getFactory().size();i++) {
            Factory f = new Factory();
            BeanUtils2.copyProperties(req.getFactory().get(i), f);
            f.setClientId(isCreate.get(0).getId());
            fMapper.insertSelective(f);
        }
        Contract con =req.getContract();
        con.setClientId(c.getId());
        contractMapper.insertSelective(con);
    }


    @Override
    public PageInfo<Client> GetAll(Page req) {
        PageHelper.startPage(req.getPageNum(),req.getPageSize());
        List<Client> clients= cMapper.selectAll(req.getOrderBy(),req.getRule());
        PageInfo<Client> resp = new PageInfo<>(clients);
        return resp;
    }

    public PageBean<T> testall(Page req){
        List<Client> clients= cMapper.selectAll(req.getOrderBy(),req.getRule());
        PageBean resp = new PageBean<>(req.getPageNum(),req.getPageSize(),clients);
        return  resp;
    };

    @Override
    public PageInfo<Client> FuzzySearch(PostKeywordSearchReq req) {
        PageHelper.startPage(req.getPage().getPageNum(),req.getPage().getPageSize());
        List<Client> clients=cMapper.FuzzySearch(req.getKeyword());
        PageInfo<Client> resp = new PageInfo<>(clients);
        return resp;
    }

    @Override
    public PageInfo<Factory> GetFactory(int client_id,Page req) {
        PageHelper.startPage(req.getPageNum(),req.getPageSize());
        List<Factory> factories= fMapper.selectByClientID(client_id);
        PageInfo<Factory> resp = new PageInfo<>(factories);
        return resp;
    }

    @Override
    public InsertClientReq Update(InsertClientReq req) {
        if (req.getClient()!=null) {
            cMapper.updateByPrimaryKeySelective(req.getClient());
        }
        if (req.getFactory().size()!=0) {
            for (Factory f : req.getFactory()) {
                if (f.getId()!=null ) {
                    fMapper.updateByPrimaryKeySelective(f);
                }else{
                    f.setClientId(req.getClient().getId());
                    fMapper.insertSelective(f);
                }

            }
        }
        if (req.getContract()!=null) {
            contractMapper.updateByPrimaryKeySelective(req.getContract());
        }
        InsertClientReq resp = new InsertClientReq();
        resp.setClient(cMapper.selectByPrimaryKey(req.getClient().getId()));
        resp.setFactory(fMapper.selectByClientID(req.getClient().getId()));
        resp.setContract(contractMapper.selectByPrimaryKey(req.getContract().getId()));
        return resp;
    }

    @Override
    public Client GetByID(int client_id) {
        return cMapper.selectByPrimaryKey(client_id);
    }

    @Override
    public int UpdateClient(Client req) {
        int resp = cMapper.updateByPrimaryKeySelective(req);
        return resp;
    }

    @Override
    public int DeleteById(int client_id) {

        return cMapper.deleteByPrimaryKey(client_id);
    }
}
