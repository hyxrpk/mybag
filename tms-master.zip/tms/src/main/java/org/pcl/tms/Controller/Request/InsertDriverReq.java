package org.pcl.tms.Controller.Request;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.pcl.tms.Model.Car;
import org.pcl.tms.Model.Driver;

@Data
@Setter
@Getter
public class InsertDriverReq {
    private Driver driver;
    private Car car;

}
