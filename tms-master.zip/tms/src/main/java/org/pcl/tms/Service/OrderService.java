package org.pcl.tms.Service;

import com.github.pagehelper.PageInfo;
import org.pcl.tms.Controller.Request.AcceptOrderReq;
import org.pcl.tms.Controller.Request.GetDriverOrderReq;
import org.pcl.tms.Controller.Request.GetOrderReq;
import org.pcl.tms.Controller.Request.InsertOrderReq;
import org.pcl.tms.Controller.Response.DriverOrder;
//import org.pcl.tms.Controller.Response.GetDriverOrderResp;
import org.pcl.tms.Model.Order;

import java.util.List;

public interface OrderService {

    Order CreateOrder(InsertOrderReq req);

    PageInfo<InsertOrderReq> ConditionSelect(GetOrderReq req);

    void UpdateOder(InsertOrderReq req);

    boolean SendInfoToDriver(String orderId,int driverId) throws Exception;

    void SendInfoToClient(InsertOrderReq req) ;

    void DeleteById(String id);

//    GetDriverOrderResp GetOrderByDriverID(GetDriverOrderReq req);

    InsertOrderReq GetOneByID(String id);

    PageInfo<DriverOrder> GetUnacceptOrder(int driverId);

    List<InsertOrderReq> GetBySo(String so);

    int CopyContractToFee(String orderID);

    PageInfo<DriverOrder> DriverUnfinishedOrder(GetDriverOrderReq req);

    PageInfo<DriverOrder> DrvierFinishedOrder(GetDriverOrderReq req);

    InsertOrderReq BindDriverAndOrder(String orderId, int driverId, float basicFee) throws Exception;

    int AcceptOrder(AcceptOrderReq req);

    PageInfo<InsertOrderReq> GetByType(GetOrderReq req);

    int BindMatuoOrder(String order1,String order2);

    int BindMatuoOrderAndDriver(String orderId1,String orderId2,int driverid, float basicFee);

    void CascadeDelete(String orderId);

    void DeleteOrders(String orders);

    void BatchUpdate(String orders, int state);

    void GeneratePDF(String path,InsertOrderReq req);

    PageInfo<InsertOrderReq> Feelist(GetOrderReq req);

    boolean NotifyDriverCancel(String orderID);
}
