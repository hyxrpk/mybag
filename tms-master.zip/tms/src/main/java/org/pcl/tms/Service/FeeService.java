package org.pcl.tms.Service;

import org.pcl.tms.Model.ExtensionFee;
import org.pcl.tms.Model.Fees;

import java.util.List;

public interface FeeService {
    int AuditFee(Fees fes);

    void deleteByOrderId(String orderID);

    List<ExtensionFee> selectAll();

    int ComputePrice(String orderId);
}
