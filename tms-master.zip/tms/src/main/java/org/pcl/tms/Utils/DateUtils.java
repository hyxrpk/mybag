package org.pcl.tms.Utils;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtils {

    public static Date String2DateHHmm(String str){
        Date time = null;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            time = sdf.parse(str);

        } catch (ParseException e) {
            e.printStackTrace();
        }
        return time;
    }
}
