package org.pcl.tms.Mapper;

import org.pcl.tms.Model.Exceptions;

import java.util.List;

public interface ExceptionsMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(Exceptions record);

    int insertSelective(Exceptions record);

    Exceptions selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(Exceptions record);

    int updateByPrimaryKey(Exceptions record);

    List<Exceptions> selectAll();
}