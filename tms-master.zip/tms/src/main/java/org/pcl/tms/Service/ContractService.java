package org.pcl.tms.Service;

import org.pcl.tms.Model.Contract;

import java.util.List;

public interface ContractService {

    void CreateContract(Contract req);

    Contract Update(Contract req);

    List<Contract> selectByClientId(int clientID);
}
