package org.pcl.tms.Model;

public class Duichang {
    private Integer id;

    private String port;

    private String duichangName;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port == null ? null : port.trim();
    }

    public String getDuichangName() {
        return duichangName;
    }

    public void setDuichangName(String duichangName) {
        this.duichangName = duichangName == null ? null : duichangName.trim();
    }
}