package org.pcl.tms.Model;

public class Car {
    private Integer id;

    private String carNum;

    private String carBrand;

    private String carDrivingLicense;

    private String carTransCert;

    private String carPhoto;

    private Integer isValid;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCarNum() {
        return carNum;
    }

    public void setCarNum(String carNum) {
        this.carNum = carNum == null ? null : carNum.trim();
    }

    public String getCarBrand() {
        return carBrand;
    }

    public void setCarBrand(String carBrand) {
        this.carBrand = carBrand == null ? null : carBrand.trim();
    }

    public String getCarDrivingLicense() {
        return carDrivingLicense;
    }

    public void setCarDrivingLicense(String carDrivingLicense) {
        this.carDrivingLicense = carDrivingLicense == null ? null : carDrivingLicense.trim();
    }

    public String getCarTransCert() {
        return carTransCert;
    }

    public void setCarTransCert(String carTransCert) {
        this.carTransCert = carTransCert == null ? null : carTransCert.trim();
    }

    public String getCarPhoto() {
        return carPhoto;
    }

    public void setCarPhoto(String carPhoto) {
        this.carPhoto = carPhoto == null ? null : carPhoto.trim();
    }

    public Integer getIsValid() {
        return isValid;
    }

    public void setIsValid(Integer isValid) {
        this.isValid = isValid;
    }
}