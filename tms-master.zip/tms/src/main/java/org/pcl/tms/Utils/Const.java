package org.pcl.tms.Utils;

import java.io.File;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.Set;

public class Const {
    public static final String serverURL= "http://119.29.195.92:8080/tms/";
    public static final String BR = "\r\n";
    public static final String webSeparator = "/";
    public static final String pathSeparator = File.pathSeparator;

    public static final String SEPARATOR = File.separator;
    public static final String CR = "\n";
    public static final int FETCH_SIZE = 5000;

    public static String NVL(String username, String string)
    {
        return ((username == null) ? string : username);
    }

    public static boolean isEmpty(Object[] os)
    {
        return ((os == null) || (os.length == 0));
    }

    public static boolean isAllEmpty(Object[] os)
    {
        if (os == null) {
            return true;
        }
        for (int i = 0; i < os.length; ++i) {
            if (!(isEmpty(os[i]))) {
                return false;
            }
        }
        return true;
    }

    @SuppressWarnings("rawtypes")
    public static boolean isEmpty(Set set)
    {
        return ((set == null) || (set.size() == 0));
    }

    @SuppressWarnings("rawtypes")
    public static boolean isEmpty(List list)
    {
        return ((list == null) || (list.size() == 0));
    }

    public static boolean isEmpty(Object value)
    {
        if (value == null)
            return true;
        if (value instanceof String) {
            return (((String)value).trim().length() == 0);
        }

        return false;
    }

    public static int toInt(Object property)
    {
        try
        {
            if (property == null)
                return 0;
            if (property instanceof String)
                return Integer.parseInt((String)property, 10);
            if (property instanceof Short)
                return ((Short)property).intValue();
            if (property instanceof Long)
                return ((Long)property).intValue();
            if (property instanceof Integer)
                return ((Integer)property).intValue();
            if (property instanceof BigInteger)
                return ((BigInteger)property).intValue();
            if (property instanceof BigDecimal) {
                return ((BigDecimal)property).intValue();
            }
            return 0;
        } catch (Exception e) {
        }
        return 0;
    }

    public static long toLong(Object property)
    {
        try
        {
            if (property == null)
                return 0L;
            if (property instanceof String)
                return Long.parseLong((String)property, 10);
            if (property instanceof Short)
                return ((Short)property).longValue();
            if (property instanceof Long)
                return ((Long)property).longValue();
            if (property instanceof Integer)
                return ((Integer)property).longValue();
            if (property instanceof BigInteger)
                return ((BigInteger)property).longValue();
            if (property instanceof BigDecimal) {
                return ((BigDecimal)property).longValue();
            }
            return 0L;
        } catch (Exception e) {
        }
        return 0L;
    }

    public static final boolean onlySpaces(String str)
    {
        for (int i = 0; i < str.length(); ++i)
            if (!(isSpace(str.charAt(i))))
                return false;
        return true;
    }

    public static final boolean isSpace(char c)
    {
        return ((c == ' ') || (c == '\t') || (c == '\r') || (c == '\n'));
    }

    public static final String trim(String str)
    {
        if (str == null) {
            return null;
        }
        int max = str.length() - 1;
        int min = 0;

        while ((min <= max) && (isSpace(str.charAt(min))))
            ++min;
        while ((max >= 0) && (isSpace(str.charAt(max)))) {
            --max;
        }
        if (max < min) {
            return "";
        }
        return str.substring(min, max + 1);
    }

    public static String toStr(Object o)
    {
        if (o == null)
            return null;
        if (o instanceof String)
            return ((String)o);
        if (o instanceof Integer)
            return ((Integer)o).intValue() + "";
        if (o instanceof Long)
            return ((Long)o).longValue() + "";
        if (o instanceof Double) {
            String s = ((Double)o).doubleValue() + "";
            int p0 = s.indexOf(".");
            if (p0 > 0) {
                String s0 = s.substring(p0 + 1);
                if (s0.replaceAll("0", "").equals("")) {
                    s = s.substring(0, p0);
                }
            }
            return s;
        }
        return o.toString();
    }

    public static String firstUpper(String type)
    {
        return type.substring(0, 1).toUpperCase() + type.substring(1);
    }

    public static String firstLower(String type)
    {
        return type.substring(0, 1).toLowerCase() + type.substring(1);
    }

    public static String gainZero(int len)
    {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < len; ++i) {
            sb.append('0');
        }
        return sb.toString();
    }

    public static boolean indexOf(String[] scope, String string)
    {
        if (scope == null) {
            return false;
        }
        return (Arrays.asList(scope).indexOf(string) > -1);
    }

    public static boolean headIndexOf(String[] scope, String string)
    {
        if ((string == null) || (scope == null)) {
            return false;
        }
        for (int i = 0; i < scope.length; ++i) {
            if ((string.equals(scope[i])) || (scope[i].startsWith(string + "."))) {
                return true;
            }
        }
        return false;
    }

    public static boolean toBoolean(Object object)
    {
        if ((isEmpty(object)) || (object.equals("0")))
            return false;
        if (object instanceof Boolean) {
            return ((Boolean)object).booleanValue();
        }
        return (toInt(object) > 0);
    }

    public static Short toShort(Object property)
    {
        try
        {
            if (property == null)
                return Short.valueOf((short) 0);
            if (property instanceof String)
                return Short.valueOf(Short.parseShort((String)property, 10));
            if (property instanceof Short)
                return ((Short)property);
            if (property instanceof Long)
                return Short.valueOf(((Long)property).shortValue());
            if (property instanceof Integer) {
                return Short.valueOf(((Integer)property).shortValue());
            }
            return Short.valueOf((short) 0);
        } catch (Exception e) {
        }
        return Short.valueOf((short) 0);
    }

    public static Float toFloat(Object property)
    {
        try
        {
            if (property == null)
                return Float.valueOf(0.0F);
            if (property instanceof Float)
                return ((Float)property);
            if (property instanceof String)
                return Float.valueOf(Float.parseFloat((String)property));
            if (property instanceof Short)
                return Float.valueOf(((Short)property).floatValue());
            if (property instanceof Long)
                return Float.valueOf(((Long)property).floatValue());
            if (property instanceof Integer) {
                return Float.valueOf(((Integer)property).floatValue());
            }
            return Float.valueOf(0.0F);
        } catch (Exception e) {
        }
        return Float.valueOf(0.0F);
    }

    public static void singleObjList(List<Object> objsList)
    {
        for (int i = 0; i < objsList.size(); ++i)
            objsList.set(i, ((Object[])(Object[])objsList.get(i))[0]);
    }

    /**
     * 检测某个对象是否指定类型
     * @param data
     * @param clazz
     * @return
     */
    public static boolean isExpectedData(Object data, Class<?> clazz) {
        if (data != null && clazz.isAssignableFrom(data.getClass())) {
            return true;
        }
        return false;
    }

    /**
     * 将某个对象转为所期待的类型，如果类型匹配的话
     * @param data
     * @param clazz
     * @return
     */
    public static <T> T getExpectedData(Object data, Class<T> clazz) {
        T expectedData = null;
        if (data != null && clazz.isAssignableFrom(data.getClass())) {
            expectedData = clazz.cast(data);
        }
        return expectedData;
    }

    /**
     * 将某个对象转为所期待的list集合，如果类型匹配的话
     * @param data
     * @param clazz
     * @return
     */
    @SuppressWarnings("unchecked")
    public static <T> List<T> getExpectedListData(Object data, Class<T> clazz) {
        List<T> expectedList = null;
        if (data != null && data instanceof List) {
            List<?> list = (List<?>)data;
            if (!list.isEmpty() && clazz.isAssignableFrom(list.get(0).getClass())) {
                expectedList =  (List<T>)data;
            }
        }
        return expectedList;
    }

    public static String genTaskId() {
        return String.format("RSS_%s_%6d", System.currentTimeMillis(), new Random().nextInt(1000000));
    }

    public static Integer genSessionId(){
        return new Random().nextInt(1000000);
    }
}
