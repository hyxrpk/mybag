package org.pcl.tms.Controller;

import lombok.extern.slf4j.Slf4j;
import org.pcl.tms.Model.Sensor;
import org.pcl.tms.Service.SensorService;
import org.pcl.tms.Utils.CodeEnum;
import org.pcl.tms.Utils.ResponseVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Slf4j
@RequestMapping("/sensor")
public class SensorController {

    @Autowired
    private SensorService sService;

    @PostMapping("/recv")
    public ResponseVo<?> RecvInfo(@RequestBody Sensor req){
        int resp = sService.Insert(req);
        if (resp!=1){
            return ResponseVo.error(CodeEnum.database_error,"insert error");
        }else {
            return ResponseVo.success();
        }
    }
}
