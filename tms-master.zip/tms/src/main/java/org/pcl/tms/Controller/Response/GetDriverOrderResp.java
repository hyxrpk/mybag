//package org.pcl.tms.Controller.Response;
//
//import com.github.pagehelper.PageInfo;
//import lombok.Data;
//import lombok.Getter;
//import lombok.Setter;
//import org.pcl.tms.Model.Driver;
//
//import java.util.List;
//
//@Data
//@Getter
//@Setter
//public class GetDriverOrderResp {
//    private PageInfo<DriverOrder> unfinished;
//    private PageInfo<DriverOrder> finished;
//}
