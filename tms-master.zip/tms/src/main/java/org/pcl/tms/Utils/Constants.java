package org.pcl.tms.Utils;

import java.io.Serializable;

//import org.hibernate.id.insert.IdentifierGeneratingInsert;

/**
 * 
  * 类名:Constants.java
  * 作者:王凡
  * 日期:2013年7月3日 下午3:54:24 
  * 说明:常量
 */
public class Constants implements Serializable {
	private static final long serialVersionUID = 1L;
	public static final String RETURN_NOPAGE_SUCCESS="SUCCESS";
	public static final String RETURN_NOPAGE_ERROR="ERROR";
	public static final String PRODUCTNAME="[ CreateSoft ]";
	public static final String BASE_USER="BASE_USER";
	public static final String BASE_FILTER="BASE_FILTER";
	
	public static final String ISDEL_Y = "Y"; //逻辑删除是
	public static final String ISDEL_N = "N"; //逻辑删除否
	
	public static final String SEX_MALE="M";//男
	public static final String SEX_FEMALE="F";//女
	
	public static final Integer PAGE_SIZE=Integer.parseInt(PropertiesUtil.readValue("./jdbc.properties","util.pageSize"));//页显示数据数量
//	public static final Integer LIMIT_NUM = Integer.parseInt(PropertiesUtil.readValue("./jdbc.properties", "util.limitNum"));
	public static final int LIMIT_NUM = 20;
	/**
	 * SimpleDateFormat
	 */
	public static final String SDF_YYYYMMDD="yyyy-MM-dd";
	public static final String SDF_YYYYMMDDHHMMSS="yyyy-MM-dd hh:mm:ss";
	public static final String SDF_HHMMSS="hh:mm:ss";
	public static final String SDF_MMDD="MM-dd";
	public static final String SDF_DD="dd";
	public static final String SDF_MM="MM";
	
	/**
	 * 文件上传常量
	 */
	public static final String UPD_RETURN_CKEDITOR="CKEDITOR";
	public static final String UPD_RETURN_TEXT="TEXT";
	public static final String UPD_RETURN_NULL=null;
	public static final String UPD_RETURN_EMPTY="";
	public static final String UPD_DIR_IMG="IMG";
	public static final String UPD_DIR_DOC="DOC";
	public static final String UPD_DIR_XLS="XLS";
	public static final String UPD_DIR_RAR="RAR";
	public static final String UPD_DIR_ZIP="ZIP";
	public static final String UPD_SUC="文件上传成功。";
	public static final String UPD_ERR="文件上传失败。";
	/**
	 * SQLUtil
	 */
	public static final String STR = "S";
	public static final String NUM = "I";
	public static final String DATE = "D";
	public static final String ISNULL = "N";
	public static final String ISNOTNULL = "INN";
	public static final String TET = "TET";
	public static final String IN = "IN";
	public static final String IN_STR = "INSTR";
	public static final String IN_NUM = "INNUM";
	public static final String LIKE = "LIKE";
	public static final String DATE_MIN = "MIN";
	public static final String DATE_YYMM = "YYMM";
	public static final String DISTINCT = "DIS";
	public static final String CLOB = "CLB";
	public static final String EXISTS = "EXISTS";
	public static final String NOTEXISTS = "NOTEXISTS";
	/**
	 * 缓存
	 */
	public static final String CACHE_KEYS = "KEYS";
	public static final String CACHE_COMPONENT = "COMP";
	public static final String CACHE_DICTIONARY = "DICT";
	
	public static final String DBTYPE="MYSQL";
	
	/**
	 * 判断是移动端还是pc
	 */
	public static final String PHONE="phone";
	public static final String PC="pc";
	/*
	 * 头像返回url固定部分
	 * */

	public static final String URL="http://if.qdocument.net:705/bic/"; 
	public static final String IMAGEPATH = "resources/userIcons/photo.png";
	
	/*
	 * 设置token过期时间
	 * */
	public static final long TOKEN_LIFE = 3600*1000*24;
	public static final String JWT_KEY = "baizhuo";

}
