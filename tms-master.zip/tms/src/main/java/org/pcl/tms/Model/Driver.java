package org.pcl.tms.Model;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Setter
@Getter
public class Driver {
    private Integer id;

    private String driverName;

    private String driverIdCard;

    private String driverIdUrlP;

    private String driverIdUrlN;

    private String driverHandId;

    private String driverLicense;

    private String driverQualificationCert;

    private String driverPhone;

    private String driverCompany;

    private Integer driverCompanyId;

    private Integer carId;

    private Integer status;

    private Integer isValid;

    private String note;

    private String payWay;

    private String account;

    private String password;

    private String regId;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDriverName() {
        return driverName;
    }

    public void setDriverName(String driverName) {
        this.driverName = driverName == null ? null : driverName.trim();
    }

    public String getDriverIdCard() {
        return driverIdCard;
    }

    public void setDriverIdCard(String driverIdCard) {
        this.driverIdCard = driverIdCard == null ? null : driverIdCard.trim();
    }

    public String getDriverIdUrlP() {
        return driverIdUrlP;
    }

    public void setDriverIdUrlP(String driverIdUrlP) {
        this.driverIdUrlP = driverIdUrlP == null ? null : driverIdUrlP.trim();
    }

    public String getDriverIdUrlN() {
        return driverIdUrlN;
    }

    public void setDriverIdUrlN(String driverIdUrlN) {
        this.driverIdUrlN = driverIdUrlN == null ? null : driverIdUrlN.trim();
    }

    public String getDriverHandId() {
        return driverHandId;
    }

    public void setDriverHandId(String driverHandId) {
        this.driverHandId = driverHandId == null ? null : driverHandId.trim();
    }

    public String getDriverLicense() {
        return driverLicense;
    }

    public void setDriverLicense(String driverLicense) {
        this.driverLicense = driverLicense == null ? null : driverLicense.trim();
    }

    public String getDriverQualificationCert() {
        return driverQualificationCert;
    }

    public void setDriverQualificationCert(String driverQualificationCert) {
        this.driverQualificationCert = driverQualificationCert == null ? null : driverQualificationCert.trim();
    }

    public String getDriverPhone() {
        return driverPhone;
    }

    public void setDriverPhone(String driverPhone) {
        this.driverPhone = driverPhone == null ? null : driverPhone.trim();
    }

    public String getDriverCompany() {
        return driverCompany;
    }

    public void setDriverCompany(String driverCompany) {
        this.driverCompany = driverCompany == null ? null : driverCompany.trim();
    }

    public Integer getDriverCompanyId() {
        return driverCompanyId;
    }

    public void setDriverCompanyId(Integer driverCompanyId) {
        this.driverCompanyId = driverCompanyId;
    }

    public Integer getCarId() {
        return carId;
    }

    public void setCarId(Integer carId) {
        this.carId = carId;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getIsValid() {
        return isValid;
    }

    public void setIsValid(Integer isValid) {
        this.isValid = isValid;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note == null ? null : note.trim();
    }

    public String getPayWay() {
        return payWay;
    }

    public void setPayWay(String payWay) {
        this.payWay = payWay == null ? null : payWay.trim();
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account == null ? null : account.trim();
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password == null ? null : password.trim();
    }

    public String getRegId() {
        return regId;
    }

    public void setRegId(String regId) {
        this.regId = regId == null ? null : regId.trim();
    }

    @Override
    public String toString() {
        return "Driver{" +
                "id=" + id +
                ", driverName='" + driverName + '\'' +
                ", driverIdCard='" + driverIdCard + '\'' +
                ", driverIdUrlP='" + driverIdUrlP + '\'' +
                ", driverIdUrlN='" + driverIdUrlN + '\'' +
                ", driverHandId='" + driverHandId + '\'' +
                ", driverLicense='" + driverLicense + '\'' +
                ", driverQualificationCert='" + driverQualificationCert + '\'' +
                ", driverPhone='" + driverPhone + '\'' +
                ", driverCompany='" + driverCompany + '\'' +
                ", driverCompanyId=" + driverCompanyId +
                ", carId=" + carId +
                ", status=" + status +
                ", isValid=" + isValid +
                ", note='" + note + '\'' +
                ", payWay='" + payWay + '\'' +
                ", account='" + account + '\'' +
                ", password='" + password + '\'' +
                ", regId='" + regId + '\'' +
                '}';
    }
}