package org.pcl.tms.Service;


import org.pcl.tms.Model.Exceptions;

import java.util.List;

public interface ExceptionService {
    List<Exceptions> GetAll();
}
