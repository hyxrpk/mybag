package org.pcl.tms.Controller.Response;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import javax.annotation.security.DenyAll;

@Data
@Setter
@Getter
public class ExtentionInfo {
    private String payWay;
    private String containerType;
    private int isUrgent;
    private String contact;
}
