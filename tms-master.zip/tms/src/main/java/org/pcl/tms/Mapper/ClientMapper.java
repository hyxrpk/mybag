package org.pcl.tms.Mapper;

import org.apache.ibatis.annotations.Param;
import org.pcl.tms.Model.Client;

import java.util.List;

public interface ClientMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(Client record);

    int insertSelective(Client record);

    Client selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(Client record);

    int updateByPrimaryKey(Client record);

    List<Client> selectByName(@Param("client_name") String client_name);

    List<Client> selectAll(@Param("order")String order,@Param("rule")String rule);

    List<Client> FuzzySearch(@Param("keyword")String keyword);
}