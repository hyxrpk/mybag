package org.pcl.tms.Service;

import com.github.pagehelper.PageInfo;
import org.pcl.tms.Controller.Request.Page;
import org.pcl.tms.Model.ContainerType;

import java.util.List;

public interface ContainerService {

    PageInfo<ContainerType> selectAll(Page req);
}
