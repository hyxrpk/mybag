package org.pcl.tms.Controller;

import lombok.extern.slf4j.Slf4j;
import org.pcl.tms.Controller.Request.GetOrderReq;
import org.pcl.tms.Service.DriverService;
import org.pcl.tms.Service.ExceptionService;
import org.pcl.tms.Utils.CodeEnum;
import org.pcl.tms.Utils.ResponseVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@Slf4j
@RequestMapping("/exception")
public class ExceptionController {

    @Autowired
    private ExceptionService eService;

    @Autowired
    private DriverService dService;

    @GetMapping("all")
    public ResponseVo<?> GettAll() {
        return ResponseVo.success(eService.GetAll());
    }


}
