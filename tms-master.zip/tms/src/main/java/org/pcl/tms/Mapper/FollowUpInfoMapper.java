package org.pcl.tms.Mapper;

import org.apache.ibatis.annotations.Param;
import org.pcl.tms.Model.FollowUpInfo;
import org.pcl.tms.Model.Order;

import java.util.List;

public interface FollowUpInfoMapper {
    int deleteByPrimaryKey(String id);

    int insert(FollowUpInfo record);

    int insertSelective(FollowUpInfo record);

    FollowUpInfo selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(FollowUpInfo record);

    int updateByPrimaryKeyWithBLOBs(FollowUpInfo record);

    int updateByPrimaryKey(FollowUpInfo record);

    List<Order> selectExceptionOrder(
            @Param("order")String order,
            @Param("rule")String rule
    );
    //TODO: unfinished
    int countExceptionOrder();

}