package org.pcl.tms.Service.Impl;

import org.pcl.tms.Mapper.ExtensionFeeMapper;
import org.pcl.tms.Mapper.FeesMapper;
import org.pcl.tms.Model.ExtensionFee;
import org.pcl.tms.Model.Fees;
import org.pcl.tms.Service.FeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FeeServiceImpl implements FeeService {

    @Autowired
    private FeesMapper fMapper;

    @Autowired
    private ExtensionFeeMapper eMapper;

    @Override
    public int AuditFee(Fees res) {
        int count = fMapper.updateByPrimaryKeySelective(res);
        return count;
    }

    @Override
    public void deleteByOrderId(String orderID) {
        fMapper.deleteByOrderId(orderID);
    }

    @Override
    public List<ExtensionFee> selectAll() {
        return eMapper.selectAll();
    }

    @Override
    public int ComputePrice(String orderId) {
        Fees tempFee = new Fees();
        tempFee.setOrderId(orderId);
        List<Fees> feesList = fMapper.getByOrder(tempFee);
        for (Fees f : feesList) {
            if (f.getType() == 1) {
                // 1是应收

            } else if (f.getType() == 2) {
                // 2是应付
            }
        }
        return 0;
    }


}
