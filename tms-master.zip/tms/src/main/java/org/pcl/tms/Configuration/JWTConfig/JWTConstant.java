package org.pcl.tms.Configuration.JWTConfig;

public interface JWTConstant {
    /**
     * 校验头key
     */
    String AUTH_HEADER_KEY = "Authorization";

    /**
     * 用户id的key
     */
    String USER_ID_KEY = "userId";

}
