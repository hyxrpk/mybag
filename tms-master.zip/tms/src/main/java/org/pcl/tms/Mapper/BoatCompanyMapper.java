package org.pcl.tms.Mapper;

import org.apache.ibatis.annotations.Param;
import org.pcl.tms.Model.BoatCompany;

import java.util.List;

public interface BoatCompanyMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(BoatCompany record);

    int insertSelective(BoatCompany record);

    BoatCompany selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(BoatCompany record);

    int updateByPrimaryKey(BoatCompany record);

    List<BoatCompany> selectAll(@Param("order_by")String Order, @Param("rule")String rule);
}