package org.pcl.tms.Service.Impl;

import org.pcl.tms.Mapper.FactoryMapper;
import org.pcl.tms.Model.Factory;
import org.pcl.tms.Service.FactoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FactoryServiceImpl implements FactoryService {

    @Autowired
    private FactoryMapper fMapper;

    @Override
    public Factory Update(Factory req) {
        fMapper.updateByPrimaryKeySelective(req);
        return fMapper.selectByPrimaryKey(req.getId());
    }

    @Override
    public Factory GetByID(int id) {
        return fMapper.selectByPrimaryKey(id);
    }

    @Override
    public int DeleteById(int id) {

        return fMapper.deleteByPrimaryKey(id);
    }
}
