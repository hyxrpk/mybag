package org.pcl.tms.Controller;

import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.formula.functions.T;
import org.pcl.tms.Controller.Request.*;
import org.pcl.tms.Model.Car;
import org.pcl.tms.Model.Client;
import org.pcl.tms.Model.Driver;
import org.pcl.tms.Service.ClientService;
import org.pcl.tms.Service.OrderService;
import org.pcl.tms.Utils.CodeEnum;
import org.pcl.tms.Utils.EmailUtils;
import org.pcl.tms.Utils.ReadExcelUtil;
import org.pcl.tms.Utils.ResponseVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.mail.MessagingException;
import javax.xml.ws.Response;
import java.util.Map;

@RestController
@Slf4j
@RequestMapping("/client")
public class ClientController {

    @Autowired
    private ClientService cService;

    @Autowired
    private OrderService oService;

    @PostMapping("parseExcel")
    public ResponseVo<?> ImportInfoFromExcel(String path) throws Exception {
        cService.InsertFromExcel(path);
        return ResponseVo.success(true);
    }

    @PostMapping("add")
    public ResponseVo<?> AddClient(@RequestBody InsertClientReq req){
        cService.AddClient(req);
        return ResponseVo.success(true);
    }

    @PostMapping("all")
    public ResponseVo<?>GetAll(@RequestBody Page req){
        return ResponseVo.success(cService.GetAll(req));
    }

    @PostMapping("keyword")
    public ResponseVo<?> GetOneByName(@RequestBody PostKeywordSearchReq req){
        return ResponseVo.success(cService.FuzzySearch(req));
    }


    @PostMapping("factorys")
    public ResponseVo<?> GetFactory(int clientId,@RequestBody Page req){
        return ResponseVo.success(cService.GetFactory(clientId,req));
    }


    @PostMapping("update")
    public ResponseVo<?> Update(@RequestBody InsertClientReq req){

        return ResponseVo.success(cService.Update(req));
    }

    @PostMapping("one")
    public ResponseVo<?> GetOne(int id){
        return ResponseVo.success(cService.GetByID(id));
    }

    @PostMapping("sendEmail")
    public ResponseVo<?>SendEmail(String orderId) throws MessagingException {
        // TODO: SendEmail
        InsertOrderReq resp = oService.GetOneByID(orderId);
        Client client = cService.GetByID(resp.getOrder().getClientId());
        EmailUtils.Send(client.getClientEmail(),"司机订单信息",resp);
        return ResponseVo.success();
    }

    @PostMapping("geng")
    public ResponseVo<?> Gengxin(@RequestBody Client client){
        int resp = cService.UpdateClient(client);
        if (resp ==0){
            return ResponseVo.error(CodeEnum.database_error,"更新数据出错");
        }
        return ResponseVo.success();
    }

    @PostMapping("delete")
    public ResponseVo<?> Delete(int clientId){
        int resp = cService.DeleteById(clientId);
        if (resp==0){
            return ResponseVo.error(CodeEnum.database_error,"删除数据出错");
        }
        return ResponseVo.success();
    }
}
