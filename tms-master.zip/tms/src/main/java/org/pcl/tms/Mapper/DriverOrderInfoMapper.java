package org.pcl.tms.Mapper;

import com.sun.tools.corba.se.idl.constExpr.Or;
import org.apache.ibatis.annotations.Param;
import org.pcl.tms.Model.Driver;
import org.pcl.tms.Model.DriverOrderInfo;
import org.pcl.tms.Model.Order;

import java.util.List;

public interface DriverOrderInfoMapper {
    int deleteByPrimaryKey(String id);

    int insert(DriverOrderInfo record);

    int insertSelective(DriverOrderInfo record);

    DriverOrderInfo selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(DriverOrderInfo record);
    int cancelDriver(DriverOrderInfo record);
    int updateByPrimaryKey(DriverOrderInfo record);

    List<DriverOrderInfo> GetByDriverID(@Param("driver_id")int driver_id);

    List<Order> GetOrderByDriverID (@Param("driver_id")int driver_i, @Param("rule")String rule, @Param("order_by")String orderBy);

    List<Order> GetCurrentMonthOrderByDriverID(@Param("driver_id")int driver_id);

    List<Order> GetOrderByDriverIDAndStatus(@Param("state")int state,@Param("driver_id")int driver_id);
}