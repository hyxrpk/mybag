package org.pcl.tms.Service;

import com.github.pagehelper.PageInfo;
import org.pcl.tms.Controller.Request.InsertDriverReq;
import org.pcl.tms.Controller.Request.InsertOrderReq;
import org.pcl.tms.Controller.Request.Page;
import org.pcl.tms.Controller.Request.UpdateDriverPwdReq;
import org.pcl.tms.Controller.Response.GetAllDriver;
import org.pcl.tms.Model.Car;
import org.pcl.tms.Model.Driver;

import java.util.List;

public interface DriverService {

    Driver Login(Driver req);

    int UpdateDriver(UpdateDriverPwdReq req);

    void insertFromExcel(String path) throws Exception;

    void insertDriverAndCar(InsertDriverReq req);

    Driver Update(Driver req);

    List<GetAllDriver> GetALlDriver(Page req);

    Driver GetById(int id);

    Car GetCarByDriverID(int id);

    void UpdateDriverAndCar(InsertDriverReq req);

    PageInfo<InsertDriverReq> AllDriver(Page req);

    InsertDriverReq GetDriverAndCar(int id);
}
