package org.pcl.tms.Controller.Request;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Setter
@Getter
public class GetDriverOrderReq {

    private int driverId;
    private int state;
    private Page page;
}
