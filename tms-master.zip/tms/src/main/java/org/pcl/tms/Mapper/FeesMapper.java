package org.pcl.tms.Mapper;

import org.apache.ibatis.annotations.Param;
import org.pcl.tms.Model.Fees;

import java.util.List;

public interface FeesMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(Fees record);

    int insertSelective(Fees record);

    Fees selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(Fees record);

    int updateByPrimaryKey(Fees record);
    List<Fees> selectAll();

    List<Fees> getByOrder(Fees record);

    void deleteByOrderId(@Param("order_id")String orderId);
}