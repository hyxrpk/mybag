package org.pcl.tms.Mapper;

import org.apache.ibatis.annotations.Param;
import org.pcl.tms.Model.Duichang;

import java.util.List;

public interface DuichangMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(Duichang record);

    int insertSelective(Duichang record);

    Duichang selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(Duichang record);

    int updateByPrimaryKey(Duichang record);

    List<Duichang> selectAll();

    List<Duichang> keywordSearch(@Param("keyword")String keyword);
}