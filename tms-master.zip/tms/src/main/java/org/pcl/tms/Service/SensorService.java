package org.pcl.tms.Service;

import org.pcl.tms.Model.Sensor;

public interface SensorService {
    int Insert(Sensor req);
}
