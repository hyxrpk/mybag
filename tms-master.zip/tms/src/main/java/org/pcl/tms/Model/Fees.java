package org.pcl.tms.Model;

public class Fees {
    private Integer id;

    private String orderId;

    private Float totalPrice;

    private Float totalExtraFee;

    private String feeList;

    private Integer contractId;

    private Integer isAudit;

    private Integer isValid;

    private Integer type;

    private Integer status;

    private Integer isYaye;

    private Float basicFee;

    private Float tax;

    private String currency;

    private String payWay;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId == null ? null : orderId.trim();
    }

    public Float getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(Float totalPrice) {
        this.totalPrice = totalPrice;
    }

    public Float getTotalExtraFee() {
        return totalExtraFee;
    }

    public void setTotalExtraFee(Float totalExtraFee) {
        this.totalExtraFee = totalExtraFee;
    }

    public String getFeeList() {
        return feeList;
    }

    public void setFeeList(String feeList) {
        this.feeList = feeList == null ? null : feeList.trim();
    }

    public Integer getContractId() {
        return contractId;
    }

    public void setContractId(Integer contractId) {
        this.contractId = contractId;
    }

    public Integer getIsAudit() {
        return isAudit;
    }

    public void setIsAudit(Integer isAudit) {
        this.isAudit = isAudit;
    }

    public Integer getIsValid() {
        return isValid;
    }

    public void setIsValid(Integer isValid) {
        this.isValid = isValid;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getIsYaye() {
        return isYaye;
    }

    public void setIsYaye(Integer isYaye) {
        this.isYaye = isYaye;
    }

    public Float getBasicFee() {
        return basicFee;
    }

    public void setBasicFee(Float basicFee) {
        this.basicFee = basicFee;
    }

    public Float getTax() {
        return tax;
    }

    public void setTax(Float tax) {
        this.tax = tax;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency == null ? null : currency.trim();
    }

    public String getPayWay() {
        return payWay;
    }

    public void setPayWay(String payWay) {
        this.payWay = payWay == null ? null : payWay.trim();
    }
}