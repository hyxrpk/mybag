package org.pcl.tms.Mapper;

import org.pcl.tms.Model.WeighingType;

public interface WeighingTypeMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(WeighingType record);

    int insertSelective(WeighingType record);

    WeighingType selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(WeighingType record);

    int updateByPrimaryKey(WeighingType record);
}