package org.pcl.tms.Service;

import org.pcl.tms.Model.User;
import org.springframework.stereotype.Service;


public interface UserService {
    int insert(User record);

    User Login(User record);
}
