package org.pcl.tms.Controller.Request;

import com.alibaba.fastjson.JSONObject;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.pcl.tms.Model.*;

@Data
@Setter
@Getter
public class InsertOrderReq {
    private Order order;
    private BusinessInfo businessInfo;
    private FollowUpInfo followUpInfo;
    private FromPHYInfo fromPHYInfo;
    private DriverOrderInfo driverOrderInfo;
    private Fees payFee;
    private Fees receiveFee;
    private Client client;
    private ExtentionInfo extentionInfo;
}
