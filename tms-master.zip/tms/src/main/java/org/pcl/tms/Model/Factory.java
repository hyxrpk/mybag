package org.pcl.tms.Model;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
@Data
@Setter
@Getter
public class Factory {
    private Integer id;

    private Integer clientId;

    private String factoryName;

    private String factoryAddress;

    private String factoryProvince;

    private String factoryCity;

    private String factoryDistrict;

    private String factoryStreet;

    private String factoryContact;

    private String factoryPhone;

    private Integer isDefault;

    private Integer isValid;

    private String longitude;

    private String latitude;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getClientId() {
        return clientId;
    }

    public void setClientId(Integer clientId) {
        this.clientId = clientId;
    }

    public String getFactoryName() {
        return factoryName;
    }

    public void setFactoryName(String factoryName) {
        this.factoryName = factoryName == null ? null : factoryName.trim();
    }

    public String getFactoryAddress() {
        return factoryAddress;
    }

    public void setFactoryAddress(String factoryAddress) {
        this.factoryAddress = factoryAddress == null ? null : factoryAddress.trim();
    }

    public String getFactoryProvince() {
        return factoryProvince;
    }

    public void setFactoryProvince(String factoryProvince) {
        this.factoryProvince = factoryProvince == null ? null : factoryProvince.trim();
    }

    public String getFactoryCity() {
        return factoryCity;
    }

    public void setFactoryCity(String factoryCity) {
        this.factoryCity = factoryCity == null ? null : factoryCity.trim();
    }

    public String getFactoryDistrict() {
        return factoryDistrict;
    }

    public void setFactoryDistrict(String factoryDistrict) {
        this.factoryDistrict = factoryDistrict == null ? null : factoryDistrict.trim();
    }

    public String getFactoryStreet() {
        return factoryStreet;
    }

    public void setFactoryStreet(String factoryStreet) {
        this.factoryStreet = factoryStreet == null ? null : factoryStreet.trim();
    }

    public String getFactoryContact() {
        return factoryContact;
    }

    public void setFactoryContact(String factoryContact) {
        this.factoryContact = factoryContact == null ? null : factoryContact.trim();
    }

    public String getFactoryPhone() {
        return factoryPhone;
    }

    public void setFactoryPhone(String factoryPhone) {
        this.factoryPhone = factoryPhone == null ? null : factoryPhone.trim();
    }

    public Integer getIsDefault() {
        return isDefault;
    }

    public void setIsDefault(Integer isDefault) {
        this.isDefault = isDefault;
    }

    public Integer getIsValid() {
        return isValid;
    }

    public void setIsValid(Integer isValid) {
        this.isValid = isValid;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude == null ? null : longitude.trim();
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude == null ? null : latitude.trim();
    }
}