package org.pcl.tms.Utils;

import cn.jsms.api.SendSMSResult;
import cn.jsms.api.ValidSMSResult;
import cn.jiguang.common.ClientConfig;
import cn.jiguang.common.ServiceHelper;
import cn.jiguang.common.connection.ApacheHttpClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import cn.jiguang.common.resp.APIConnectionException;
import cn.jiguang.common.resp.APIRequestException;
import cn.jsms.api.common.SMSClient;
import cn.jsms.api.common.model.SMSPayload;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class JSMSUtils {

    protected static final Logger LOG = LoggerFactory.getLogger(JSMSUtils.class);

    private static String AppKey;

    private static String MasterKey;

    @Value("${jg.AppKey}")
    public void setAppKey(String appKey) {
        this.AppKey = appKey;
    }

    @Value("${jg.MasterKey}")
    public void setMasterKey(String masterKey) {
        this.MasterKey = masterKey;
    }


    public static String SendSMSCode(String phoneNum) throws APIConnectionException, APIRequestException {
        SMSClient client = new SMSClient(MasterKey, AppKey);
        SMSPayload payload = SMSPayload.newBuilder()
                .setMobileNumber(phoneNum)
                .setTempId(1)
                .setSignId(8668)
                .build();
            SendSMSResult res = client.sendSMSCode(payload);
            return res.getMessageId();
    }

    public static boolean VerifyCode(String msgId,String code) throws APIConnectionException, APIRequestException {
        SMSClient client = new SMSClient(MasterKey, AppKey);
        ValidSMSResult res = client.sendValidSMSCode(msgId, code );
        return res.getIsValid();
    }

}