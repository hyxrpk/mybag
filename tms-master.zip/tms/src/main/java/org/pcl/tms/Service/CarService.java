package org.pcl.tms.Service;

import org.pcl.tms.Model.Car;

public interface CarService {

    Car GetByID(int id);
}
