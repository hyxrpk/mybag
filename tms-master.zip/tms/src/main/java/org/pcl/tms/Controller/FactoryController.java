package org.pcl.tms.Controller;


import lombok.extern.slf4j.Slf4j;
import org.pcl.tms.Model.Factory;
import org.pcl.tms.Service.FactoryService;
import org.pcl.tms.Utils.CodeEnum;
import org.pcl.tms.Utils.ResponseVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Slf4j
@RequestMapping("/factory")
public class FactoryController {

    @Autowired
    private FactoryService fService;

    @PostMapping("update")
    public ResponseVo<?> Update(@RequestBody Factory req){
        return ResponseVo.success(fService.Update(req));
    }

    @PostMapping("one")
    public ResponseVo<?> GetONe(int id) {
        return ResponseVo.success(fService.GetByID(id));
    }

    @PostMapping("delete")
    public ResponseVo<?> DeleteOne(int id) {
        int result = fService.DeleteById(id);
        if (result ==0){
            return ResponseVo.error(CodeEnum.database_error);
        }else {
            return ResponseVo.success();
        }
    }
}
