package org.pcl.tms.Model;

public class WeighingType {
    private Integer id;

    private String weighingName;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getWeighingName() {
        return weighingName;
    }

    public void setWeighingName(String weighingName) {
        this.weighingName = weighingName == null ? null : weighingName.trim();
    }
}