package org.pcl.tms.Mapper;

import org.apache.ibatis.annotations.Param;
import org.pcl.tms.Model.BusinessInfo;

import java.util.List;

public interface BusinessInfoMapper {
    int deleteByPrimaryKey(String id);

    int insert(BusinessInfo record);

    int insertSelective(BusinessInfo record);

    BusinessInfo selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(BusinessInfo record);

    int updateByPrimaryKey(BusinessInfo record);

    List<BusinessInfo> selectBySo(@Param("so_num") String so_num);
}