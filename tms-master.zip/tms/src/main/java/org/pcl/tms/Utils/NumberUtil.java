package org.pcl.tms.Utils;

import java.text.DecimalFormat;

public class NumberUtil{
    /** 
     * 将double类型的数字保留两位小数（四舍五入） 
     *  
     * @param number 
     * @return 
     */  
    public static String formatNumber(double number) {  
        DecimalFormat df = new DecimalFormat();  
        df.applyPattern("#0.00");  
        return df.format(number);  
    }  
    /** 
     * 判断字符串是否可转换成数字 
     * @param fileName 源串 
     * @return boolean 
     */ 
    public static boolean isNumber(String strInput){ 
        boolean bRs=false; 
        int nRs=0; 
        try{ 
            nRs=Integer.parseInt(strInput); 
            bRs=true; 
        }catch(Exception e){ 
            bRs=false; 
        } 
            return bRs; 
    }
    /** 
     * 判断String是否是整数 
     */  
     public static boolean isInteger(String s){  
         if((s != null)&&(s!=""))  
          return s.matches("^[0-9]*$");  
         else  
          return false;  
     }  
     /** 
     * 判断字符串是否是浮点数 
     */  
     public static boolean isDouble(String value) {  
         try {  
            Double.parseDouble(value);  
            if (value.contains("."))  
                return true;  
            return false;  
         } catch (NumberFormatException e) {  
            return false;  
         }  
     }

}
