package org.pcl.tms.Service;

import com.github.pagehelper.PageInfo;
import org.apache.poi.ss.formula.functions.T;
import org.pcl.tms.Controller.Request.InsertClientReq;
import org.pcl.tms.Controller.Request.Page;
import org.pcl.tms.Controller.Request.PostKeywordSearchReq;
import org.pcl.tms.Model.Client;
import org.pcl.tms.Model.Factory;
import org.pcl.tms.Utils.PageBean;

import java.util.List;

public interface ClientService {
    void InsertFromExcel(String path) throws Exception;

    void AddClient(InsertClientReq req);

    PageInfo<Client> GetAll(Page req);

    PageInfo<Client> FuzzySearch(PostKeywordSearchReq req);

    PageInfo<Factory> GetFactory(int client_id,Page req);

    InsertClientReq Update(InsertClientReq client);

    Client GetByID(int client_id);

    int UpdateClient(Client req);

    int DeleteById(int client_id);

    PageBean<T> testall(Page req);
}
