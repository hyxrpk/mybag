package org.pcl.tms.Service.Impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.pcl.tms.Controller.Request.Page;
import org.pcl.tms.Mapper.ContainerTypeMapper;
import org.pcl.tms.Model.Client;
import org.pcl.tms.Model.ContainerType;
import org.pcl.tms.Model.Contract;
import org.pcl.tms.Service.ContainerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class ContainerServiceImpl implements ContainerService {

    @Autowired
    private ContainerTypeMapper ctMapper;

    @Override
    public PageInfo<ContainerType> selectAll(Page req) {
        PageHelper.startPage(req.getPageNum(),req.getPageSize());
        List<ContainerType> containerTypes = ctMapper.selectAll();
        PageInfo<ContainerType> resp = new PageInfo<>(containerTypes);
        return resp;
    }
}
