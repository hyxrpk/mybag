package org.pcl.tms.Controller;

import cn.jiguang.common.resp.APIConnectionException;
import cn.jiguang.common.resp.APIRequestException;
import cn.jsms.api.SendSMSResult;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.jsonwebtoken.Claims;
import lombok.extern.slf4j.Slf4j;

import org.apache.poi.ss.formula.functions.T;
import org.pcl.tms.Configuration.JWTConfig.JWTConstant;
import org.pcl.tms.Configuration.JWTConfig.JWTIgnore;
import org.pcl.tms.Controller.Request.*;
import org.pcl.tms.Controller.Response.DriverLoginResp;
import org.pcl.tms.Controller.Response.DriverOrder;
import org.pcl.tms.Controller.Response.GetAllDriver;
import org.pcl.tms.Mapper.DriverMapper;
import org.pcl.tms.Model.Driver;
import org.pcl.tms.Model.JWTParam;
import org.pcl.tms.Service.DriverService;
import org.pcl.tms.Service.OrderService;
import org.pcl.tms.Utils.*;
import org.pcl.tms.Utils.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;


@RestController
@Slf4j
@RequestMapping("/driver")
public class DriverController {

    @Autowired
    private DriverService dService;
    @Autowired
    private DriverMapper dMapper;
    @Autowired
    private JWTParam jwtParam;

    @Autowired
    private OrderService oService;

    @JWTIgnore
    @PostMapping("login")
    public ResponseVo<?> Login(@RequestBody Driver req) {
        Driver d = dService.Login(req);
        if (d == null) {
            return ResponseVo.error(CodeEnum.user_not_found, "登陆失败");
        } else {
            String token = JWTUtils.createToken(String.valueOf(d.getId()), jwtParam);
            DriverLoginResp resp = new DriverLoginResp();
            resp.setDriver(d);
            resp.setToken(token);
            return ResponseVo.success(resp);
        }
    }

    @JWTIgnore
    @PostMapping("parseExcel")
    public ResponseVo<T> ParseExcel(String path) throws Exception {
        dService.insertFromExcel(path);
        return ResponseVo.success();
    }

    @JWTIgnore
    @PostMapping("add")
    public ResponseVo<?> AddDriver(@RequestBody InsertDriverReq req){
        dService.insertDriverAndCar(req);
        return ResponseVo.success();
    }

    @PostMapping("update")
    public ResponseVo<?> Update(@RequestBody Driver req){
        return ResponseVo.success(dService.Update(req));
    }


    @PostMapping("all")
    public ResponseVo<?> GetAll(@RequestBody GetOrderReq req) {
        if (req.getState()==0){
            PageHelper.startPage(req.getPage().getPageNum(), req.getPage().getPageSize());
            List<GetAllDriver> resp =dService.GetALlDriver(req.getPage());
            PageInfo<GetAllDriver> res = new PageInfo<GetAllDriver>(resp);
            int usableDriverNum = dMapper.availableDrvier().size();
            res.setTotal(usableDriverNum);
            res.setHasNextPage(Page.isHasNext(usableDriverNum,req.getPage().getPageSize(),req.getPage().getPageNum()));
            return ResponseVo.success(res);
        }else if (req.getState()==1){
            return ResponseVo.success(dService.AllDriver(req.getPage()));
        }
        return ResponseVo.error(CodeEnum.not_found_error,"wrong state info");
    }

    // 根据token获取用户信息
    @GetMapping("info")
    public ResponseVo<?> GetOne(HttpServletRequest request){
        String authHeader = request.getHeader(JWTConstant.AUTH_HEADER_KEY);
        final String authToken = JWTUtils.getRawToken(authHeader);
        Claims claims = JWTUtils.parseToken(authToken, jwtParam.getBase64Secret());
        int id = Integer.parseInt(String.valueOf(claims.get("userId")));
        return ResponseVo.success(dService.GetById(id));
    }

    @PostMapping("order")
    public ResponseVo<?> GetOrder(@RequestBody GetDriverOrderReq req){
        if (req.getState()==0){
            PageInfo<DriverOrder> resp = oService.DriverUnfinishedOrder(req);
            if (resp ==null){
                return ResponseVo.success();
            }
            return ResponseVo.success(resp);
        }else if(req.getState()==1){
            PageInfo<DriverOrder> resp = oService.DrvierFinishedOrder(req);
            if (resp ==null){
                return ResponseVo.success();
            }
            return ResponseVo.success(resp);
        }
        return ResponseVo.error(CodeEnum.not_found_error,"wrong state");
    }
    // 获取车辆信息
    @GetMapping("car")
    public ResponseVo<?> GetCar(int driverId){
        return ResponseVo.success(dService.GetCarByDriverID(driverId));
    }

    @PostMapping("updatecar")
    public ResponseVo<?> UpdateCar(@RequestBody InsertDriverReq req){
        dService.UpdateDriverAndCar(req);
        return ResponseVo.success();
    }

    @GetMapping("unacceptorder")
    public ResponseVo<?> GetUnacceptOrder(int driverId) {
        return ResponseVo.success(oService.GetUnacceptOrder(driverId));
    }

    @PostMapping("code")
    public ResponseVo<?> SendCode(@RequestBody PostCodeReq req) throws APIConnectionException, APIRequestException {
        String resp = JSMSUtils.SendSMSCode(req.getPhone());
        return ResponseVo.success(resp);
    }


    @PostMapping("verify")
    public ResponseVo<?> VerifyCode(@RequestBody PostCodeReq req) throws APIConnectionException, APIRequestException {
        boolean flag= JSMSUtils.VerifyCode(req.getMsgId(),req.getCode());
        if (flag){
        return ResponseVo.success();
        }else {
            return ResponseVo.error();
        }
    }


    @PostMapping("bindorder")
    public ResponseVo<?> BindOrder(String orderId, int driverId, Float basicFee) throws Exception {
        return ResponseVo.success(oService.BindDriverAndOrder(orderId,driverId,basicFee));
    }

    @PostMapping("accept")
    public ResponseVo<?> AcceptOrder(@RequestBody AcceptOrderReq req){
        int res= oService.AcceptOrder(req);
        if (res ==0) {
            return ResponseVo.error(CodeEnum.database_error,"更新错误或参数错误");
        }else if (res ==-1){
            return ResponseVo.error(CodeEnum.valueOf("订单状态有误,无法绑定"));
        }
        return ResponseVo.success();
    }

    @JWTIgnore
    @GetMapping("one")
    public ResponseVo<?> GetDriver(int id){
        return ResponseVo.success(dService.GetDriverAndCar(id));
    }
}

