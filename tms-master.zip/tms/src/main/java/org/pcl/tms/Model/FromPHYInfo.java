package org.pcl.tms.Model;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.util.Date;

public class FromPHYInfo {
    private String id;

    private String tiguiAddress;

    private String haiguiAddress;

    private String eirUrl;

    private String boatName;

    private String hangci;

    private String soNum;

    private Integer isValid;

    private String tiguiDuichang;

    private String haiguiDuichang;

    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    private Date jieguanShijian;

    private String soHouzhui;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getTiguiAddress() {
        return tiguiAddress;
    }

    public void setTiguiAddress(String tiguiAddress) {
        this.tiguiAddress = tiguiAddress == null ? null : tiguiAddress.trim();
    }

    public String getHaiguiAddress() {
        return haiguiAddress;
    }

    public void setHaiguiAddress(String haiguiAddress) {
        this.haiguiAddress = haiguiAddress == null ? null : haiguiAddress.trim();
    }

    public String getEirUrl() {
        return eirUrl;
    }

    public void setEirUrl(String eirUrl) {
        this.eirUrl = eirUrl == null ? null : eirUrl.trim();
    }

    public String getBoatName() {
        return boatName;
    }

    public void setBoatName(String boatName) {
        this.boatName = boatName == null ? null : boatName.trim();
    }

    public String getHangci() {
        return hangci;
    }

    public void setHangci(String hangci) {
        this.hangci = hangci == null ? null : hangci.trim();
    }

    public String getSoNum() {
        return soNum;
    }

    public void setSoNum(String soNum) {
        this.soNum = soNum == null ? null : soNum.trim();
    }

    public Integer getIsValid() {
        return isValid;
    }

    public void setIsValid(Integer isValid) {
        this.isValid = isValid;
    }

    public String getTiguiDuichang() {
        return tiguiDuichang;
    }

    public void setTiguiDuichang(String tiguiDuichang) {
        this.tiguiDuichang = tiguiDuichang == null ? null : tiguiDuichang.trim();
    }

    public String getHaiguiDuichang() {
        return haiguiDuichang;
    }

    public void setHaiguiDuichang(String haiguiDuichang) {
        this.haiguiDuichang = haiguiDuichang == null ? null : haiguiDuichang.trim();
    }

    public Date getJieguanShijian() {
        return jieguanShijian;
    }

    public void setJieguanShijian(Date jieguanShijian) {
        this.jieguanShijian = jieguanShijian;
    }

    public String getSoHouzhui() {
        return soHouzhui;
    }

    public void setSoHouzhui(String soHouzhui) {
        this.soHouzhui = soHouzhui == null ? null : soHouzhui.trim();
    }
}