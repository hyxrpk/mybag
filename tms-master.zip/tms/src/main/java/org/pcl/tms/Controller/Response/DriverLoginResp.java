package org.pcl.tms.Controller.Response;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.pcl.tms.Model.Driver;

@Setter
@Getter
@Data
public class DriverLoginResp {
    Driver driver;
    String token;
}
