package org.pcl.tms.Controller.Request;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Setter
@Getter
public class AcceptOrderReq {
    String[]  orders;
    int driverId;
}
