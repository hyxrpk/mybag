package org.pcl.tms.Model;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Data
@Setter
@Getter
public class Order {
    private String id;

    private Integer clientId;

    private String businessInfoId;

    private Integer isValid;
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    private Date duguiTime;

    private String duguiduichangAddress;

    private Integer isSave;

    private Integer isSendSuccess;

    private String followUpId;

    private Date createTime;

    private String factoryId;

    private Integer isSubmit;

    private Integer processStatus;

    private Integer carStatus;

    private String fromPhyId;

    private String driverOrderId;

    private String doubleRelatedOrder;

    private Integer isSelected;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public Integer getClientId() {
        return clientId;
    }

    public void setClientId(Integer clientId) {
        this.clientId = clientId;
    }

    public String getBusinessInfoId() {
        return businessInfoId;
    }

    public void setBusinessInfoId(String businessInfoId) {
        this.businessInfoId = businessInfoId == null ? null : businessInfoId.trim();
    }

    public Integer getIsValid() {
        return isValid;
    }

    public void setIsValid(Integer isValid) {
        this.isValid = isValid;
    }

    public Date getDuguiTime() {
        return duguiTime;
    }

    public void setDuguiTime(Date duguiTime) {
        this.duguiTime = duguiTime;
    }

    public String getDuguiduichangAddress() {
        return duguiduichangAddress;
    }

    public void setDuguiduichangAddress(String duguiduichangAddress) {
        this.duguiduichangAddress = duguiduichangAddress == null ? null : duguiduichangAddress.trim();
    }

    public Integer getIsSave() {
        return isSave;
    }

    public void setIsSave(Integer isSave) {
        this.isSave = isSave;
    }

    public Integer getIsSendSuccess() {
        return isSendSuccess;
    }

    public void setIsSendSuccess(Integer isSendSuccess) {
        this.isSendSuccess = isSendSuccess;
    }

    public String getFollowUpId() {
        return followUpId;
    }

    public void setFollowUpId(String followUpId) {
        this.followUpId = followUpId == null ? null : followUpId.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getFactoryId() {
        return factoryId;
    }

    public void setFactoryId(String factoryId) {
        this.factoryId = factoryId == null ? null : factoryId.trim();
    }

    public Integer getIsSubmit() {
        return isSubmit;
    }

    public void setIsSubmit(Integer isSubmit) {
        this.isSubmit = isSubmit;
    }

    public Integer getProcessStatus() {
        return processStatus;
    }

    public void setProcessStatus(Integer processStatus) {
        this.processStatus = processStatus;
    }

    public Integer getCarStatus() {
        return carStatus;
    }

    public void setCarStatus(Integer carStatus) {
        this.carStatus = carStatus;
    }

    public String getFromPhyId() {
        return fromPhyId;
    }

    public void setFromPhyId(String fromPhyId) {
        this.fromPhyId = fromPhyId == null ? null : fromPhyId.trim();
    }

    public String getDriverOrderId() {
        return driverOrderId;
    }

    public void setDriverOrderId(String driverOrderId) {
        this.driverOrderId = driverOrderId == null ? null : driverOrderId.trim();
    }

    public String getDoubleRelatedOrder() {
        return doubleRelatedOrder;
    }

    public void setDoubleRelatedOrder(String doubleRelatedOrder) {
        this.doubleRelatedOrder = doubleRelatedOrder == null ? null : doubleRelatedOrder.trim();
    }

    public Integer getIsSelected() {
        return isSelected;
    }

    public void setIsSelected(Integer isSelected) {
        this.isSelected = isSelected;
    }
}