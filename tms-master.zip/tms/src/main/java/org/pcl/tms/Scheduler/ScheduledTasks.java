package org.pcl.tms.Scheduler;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.Date;

@Component
public class ScheduledTasks {

    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");

    @Scheduled(fixedRate = 600000)
    public void OrderMonitor() {
        System.out.println("当前时间：" + dateFormat.format(new Date()));
    }

    //TODO: 检查用户是否接单
    @Scheduled(fixedRate = 600000)
    public void IsDriverAccept(){

    }
}
