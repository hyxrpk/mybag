package org.pcl.tms.Service.Impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.pcl.tms.Controller.Request.InsertDriverReq;
import org.pcl.tms.Controller.Request.Page;
import org.pcl.tms.Controller.Request.UpdateDriverPwdReq;
import org.pcl.tms.Controller.Response.GetAllDriver;
import org.pcl.tms.Mapper.*;
import org.pcl.tms.Model.*;
import org.pcl.tms.Service.DriverService;
//import org.pcl.tms.Utils.HasNext;
import org.pcl.tms.Utils.ReadExcelUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class DriverServiceImpl implements DriverService {

    @Autowired
    private DriverMapper dMapper;

    @Autowired
    private CarMapper carMapper;

    @Autowired
    private DriverOrderInfoMapper doiMapper;

    @Autowired
    private OrderMapper oMapper;

    @Autowired
    private SMSCodeMapper smsCodeMapper;
    @Override
    public Driver Login(Driver req) {
        Driver driver = dMapper.selectByAccountAndPwd(req);
        return driver;
    }

    @Override
    public int UpdateDriver(UpdateDriverPwdReq req) {
        SMSCode isExist=smsCodeMapper.selectLatestCode(req.getDriverPhone());
        if (isExist==null){
            return 0;
        }
        int res = dMapper.updateByPrimaryKeySelective(req);
        return res;
    }

    @Override
    public void insertFromExcel(String path) throws Exception {
        ReadExcelUtil excelReader = new ReadExcelUtil(path);
        Map<Integer, Map<Integer, Object>> map = excelReader.readExcelContent();

        for (int i = 1; i <= map.size(); i++) {
            Map<Integer, Object> row = map.get(i);
            Car car = new Car();
            car.setCarNum((String) row.get(5));
            car.setCarBrand((String) row.get(6));
            Car isCreate = carMapper.selectByCarNum(car);
            if (isCreate == null) {
                carMapper.insertSelective(car);
            }
            Car create = carMapper.selectByCarNum(car);

            Driver d = new Driver();
            d.setDriverName((String) row.get(0));
            String num =row.get(1).toString();
            d.setDriverIdCard(num);
            String ph = row.get(2).toString();
            BigDecimal pho = new BigDecimal(ph);
            d.setDriverPhone(pho.toPlainString());
            d.setDriverCompany((String) row.get(3));
            d.setNote((String) row.get(4));
            d.setPayWay((String) row.get(7));
            d.setCarId(create.getId());
            d.setAccount(pho.toPlainString());
            d.setPassword("123456");
            Driver isExist = dMapper.selectByNameAndIDCard(d);
            if(isExist==null){
                dMapper.insertSelective(d);
            }
        }
    }

//    @Override
    public void insertDriverAndCar(InsertDriverReq req) {

        Car c = new Car();
        Driver d = new Driver();
        c.setCarNum(req.getCar().getCarNum());
        c.setCarBrand(req.getCar().getCarBrand());
        c.setCarDrivingLicense(req.getCar().getCarDrivingLicense());
        c.setCarPhoto(req.getCar().getCarPhoto());
        c.setCarTransCert(req.getCar().getCarTransCert());
        Car isExist = carMapper.selectByCarNum(c);
        if(isExist==null){
            carMapper.insert(c);
        }
        Car isCreate = carMapper.selectByCarNum(c);
        d.setCarId(isCreate.getId());
        d.setAccount(req.getDriver().getDriverPhone());
        d.setPassword("123456");
        d.setDriverName(req.getDriver().getDriverName());
        d.setDriverIdCard(req.getDriver().getDriverIdCard());
        d.setDriverIdUrlP(req.getDriver().getDriverIdUrlP());
        d.setDriverIdUrlN(req.getDriver().getDriverIdUrlN());
        d.setDriverCompany(req.getDriver().getDriverCompany());
        d.setDriverHandId(req.getDriver().getDriverHandId());
        d.setDriverPhone(req.getDriver().getDriverPhone());
//        d.setDriverCompanyId(req.getDriver().getDriverCompanyId());
        d.setDriverCompany(req.getDriver().getDriverCompany());
        d.setDriverLicense(req.getDriver().getDriverLicense());
        d.setDriverQualificationCert(req.getDriver().getDriverQualificationCert());
        d.setNote(req.getDriver().getNote());
        d.setPayWay(req.getDriver().getPayWay());
        d.setStatus(req.getDriver().getStatus());
        Driver isDriverExist = dMapper.selectByNameAndIDCard(d);
        if (isDriverExist == null){
            dMapper.insertSelective(d);
        }
    }

    @Override
    public Driver Update(Driver req) {
        dMapper.updateByPrimaryKeySelective(req);
        return dMapper.selectByPrimaryKey(req.getId());
    }

    @Override
    public List<GetAllDriver> GetALlDriver(Page req) {
        List<Driver> drivers = dMapper.selectAllByStatus();//
        List<GetAllDriver> respList = new ArrayList<>();
        for (Driver d : drivers) {
            GetAllDriver resp = new GetAllDriver();
            resp.setDriverId(d.getId());
            resp.setDriverName(d.getDriverName());
            resp.setNote(d.getNote());
            resp.setCurrentLocation("现在没办法获取");
            //TODO: 计算司机当月订单数
            List<Order> orders = doiMapper.GetCurrentMonthOrderByDriverID(d.getId());
            resp.setOrderCount(orders.size());
            //TODO: 计算司机当月费用
            Car car = carMapper.selectByPrimaryKey(d.getCarId());
            resp.setCarNum(car.getCarNum());
            int flag = 1;
            for (Order o : orders){
                // TODO: 判断车辆状态
                Order one = oMapper.selectByPrimaryKey(o.getId());
                // TODO:需要再加上车辆的状态
                // 如果有一条order的status=4， 这个司机就不能接单
                if (one.getProcessStatus()==4){
                    flag=0;
                    break;
                }
            }
            if (orders.size()==0){
                flag=1;
            }
            if (flag!=0) {
                respList.add(resp);
            }
        }
        return respList;
    }

    @Override
    public Driver GetById(int id) {
        return dMapper.selectByPrimaryKey(id);
    }

    @Override
    public Car GetCarByDriverID(int id) {
        Driver d = dMapper.selectByPrimaryKey(id);
        return carMapper.selectByPrimaryKey(d.getCarId());
    }

    @Override
    public void UpdateDriverAndCar(InsertDriverReq req) {
        dMapper.updateByPrimaryKeySelective(req.getDriver());
        carMapper.updateByPrimaryKeySelective(req.getCar());
    }

    @Override
    public PageInfo<InsertDriverReq> AllDriver(Page req) {
        PageHelper.startPage(req.getPageNum(),req.getPageSize());
        List<Driver> drivers = dMapper.selectAll();
        List<InsertDriverReq> resp = new ArrayList<>();
        for (Driver d: drivers){
            InsertDriverReq one = new InsertDriverReq();
            one.setDriver(d);
            one.setCar(carMapper.selectByPrimaryKey(d.getCarId()));
            resp.add(one);
        }
        PageInfo<InsertDriverReq> res = new PageInfo<>(resp);
        int countDriver  = dMapper.countAll();
        res.setTotal(countDriver);
        res.setHasNextPage(org.pcl.tms.Utils.Page.isHasNext(countDriver,req.getPageSize(),req.getPageNum()));
        return res;
    }

    @Override
    public InsertDriverReq GetDriverAndCar(int id) {
        Driver d = dMapper.selectByPrimaryKey(id);
        Car c = carMapper.selectByPrimaryKey(d.getCarId());
        InsertDriverReq resp = new InsertDriverReq();
        resp.setDriver(d);
        resp.setCar(c);
        return resp;
    }


}
