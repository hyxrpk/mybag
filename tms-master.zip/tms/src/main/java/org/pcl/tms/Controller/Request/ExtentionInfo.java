package org.pcl.tms.Controller.Request;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.pcl.tms.Model.Driver;
import org.pcl.tms.Model.Factory;

import java.util.List;

@Data
@Setter
@Getter
public class ExtentionInfo {
    private List<Factory> factorys;
    private String container;
    private String payWay;
    private String boatCompany;
    private String carNum;
    private String contactNum;
    private Driver driver;
    private int isUrgent; // 0为否,1为是
}
