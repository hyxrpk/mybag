package org.pcl.tms.Controller.Request;


import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Setter
@Getter
public class Page {
    private int pageNum;
    private int pageSize;
    private String orderBy;
    private String rule;
}
