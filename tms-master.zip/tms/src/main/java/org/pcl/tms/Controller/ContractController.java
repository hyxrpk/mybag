package org.pcl.tms.Controller;

import lombok.extern.slf4j.Slf4j;
import org.pcl.tms.Model.Contract;
import org.pcl.tms.Service.ContractService;
import org.pcl.tms.Utils.ResponseVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Slf4j
@RequestMapping("/contract")
public class ContractController {

    @Autowired
    private ContractService cService;

    @PostMapping("add")
    public ResponseVo<?> AddContract(@RequestBody Contract req){
        cService.CreateContract(req);
        return ResponseVo.success();
    }

    @PostMapping("update")
    public ResponseVo<?> UpdateContract(@RequestBody Contract req){
        return ResponseVo.success(cService.Update(req));
    }

    @PostMapping("user")
    public ResponseVo<?> GetUserContract(int clientId){
        return ResponseVo.success(cService.selectByClientId(clientId));
    }
}
