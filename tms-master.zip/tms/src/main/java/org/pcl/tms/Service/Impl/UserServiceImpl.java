package org.pcl.tms.Service.Impl;

import org.pcl.tms.Mapper.UserMapper;
import org.pcl.tms.Model.User;
import org.pcl.tms.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserMapper uMapper;

    @Override
    public int insert(User record) {
        int count = uMapper.insert(record);
        return count;
    }

    @Override
    public User Login(User record) {
        return uMapper.login(record);

    }


}
