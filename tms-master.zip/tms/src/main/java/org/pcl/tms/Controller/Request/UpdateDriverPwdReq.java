package org.pcl.tms.Controller.Request;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.pcl.tms.Model.Driver;

@Data
@Setter
@Getter
public class UpdateDriverPwdReq extends Driver {
    private String code;
}
