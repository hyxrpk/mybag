package org.pcl.tms.Controller;

import lombok.extern.slf4j.Slf4j;
import org.pcl.tms.Controller.Request.Page;
import org.pcl.tms.Mapper.DuichangMapper;
import org.pcl.tms.Service.BoatService;
import org.pcl.tms.Utils.ResponseVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@Slf4j
@RequestMapping("/boat")
public class BoatController {

    @Autowired
    private BoatService bService;

    @Autowired
    private DuichangMapper dcMapper;

    @PostMapping("all")
    public ResponseVo<?> GetAll(@RequestBody Page page){
        return ResponseVo.success(bService.GetAll(page));
    }

    @GetMapping("duichang")
    public ResponseVo GetAllDuichang(String keyword){
        return ResponseVo.success(dcMapper.keywordSearch(keyword));
    }
}
