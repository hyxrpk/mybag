package org.pcl.tms;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
@MapperScan(value = "org.pcl.tms.Mapper")
public class TmsApplication extends SpringBootServletInitializer {

    public static void main(String[] args) {
        SpringApplication.run(TmsApplication.class, args);
    }

}
