package org.pcl.tms.Service.Impl;

import org.pcl.tms.Mapper.ContractMapper;
import org.pcl.tms.Model.Contract;
import org.pcl.tms.Service.ContractService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ContractServiceImpl implements ContractService {

    @Autowired
    private ContractMapper contractMapper;

    @Override
    public void CreateContract(Contract req) {
        contractMapper.insertSelective(req);
    }

    @Override
    public Contract Update(Contract req) {
        contractMapper.updateByPrimaryKeySelective(req);
        return contractMapper.selectByPrimaryKey(req.getId());
    }

    @Override
    public List<Contract> selectByClientId(int clientID) {
        return contractMapper.selectByClientId(clientID);
    }

}
