package org.pcl.tms.Mapper;

import org.apache.ibatis.annotations.Param;
import org.pcl.tms.Model.Contract;

import java.util.List;

public interface ContractMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(Contract record);

    int insertSelective(Contract record);

    Contract selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(Contract record);

    int updateByPrimaryKey(Contract record);

    List<Contract> selectByClientId(@Param("client_id")int client_id);
}