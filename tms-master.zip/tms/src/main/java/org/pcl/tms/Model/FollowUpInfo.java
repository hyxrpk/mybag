package org.pcl.tms.Model;

public class FollowUpInfo {
    private String id;

    private String worksheetUrl;

    private Integer exceptionId;

    private Integer isValid;

    private String exceptionDecription;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getWorksheetUrl() {
        return worksheetUrl;
    }

    public void setWorksheetUrl(String worksheetUrl) {
        this.worksheetUrl = worksheetUrl == null ? null : worksheetUrl.trim();
    }

    public Integer getExceptionId() {
        return exceptionId;
    }

    public void setExceptionId(Integer exceptionId) {
        this.exceptionId = exceptionId;
    }

    public Integer getIsValid() {
        return isValid;
    }

    public void setIsValid(Integer isValid) {
        this.isValid = isValid;
    }

    public String getExceptionDecription() {
        return exceptionDecription;
    }

    public void setExceptionDecription(String exceptionDecription) {
        this.exceptionDecription = exceptionDecription == null ? null : exceptionDecription.trim();
    }
}