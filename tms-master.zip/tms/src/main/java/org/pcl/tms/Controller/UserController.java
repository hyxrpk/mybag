package org.pcl.tms.Controller;


import cn.jiguang.common.resp.APIConnectionException;
import cn.jiguang.common.resp.APIRequestException;
import com.itextpdf.text.DocumentException;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.pcl.tms.Controller.Request.GetDriverOrderReq;
import org.pcl.tms.Controller.Request.IdRequest;
import org.pcl.tms.Controller.Request.InsertOrderReq;
import org.pcl.tms.Controller.Response.UserLoginResp;
import org.pcl.tms.Model.Fee;
import org.pcl.tms.Model.JWTParam;
import org.pcl.tms.Model.User;
import org.pcl.tms.Service.OrderService;
import org.pcl.tms.Service.UserService;
import org.pcl.tms.Utils.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.ResourceUtils;
import org.springframework.web.bind.annotation.*;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

@RestController
@Slf4j
@RequestMapping("/user")
public class UserController {

    @Value("${email.account}")
    private String account;

    @Value("${email.password}")
    private String password;

    @Autowired
    private OrderService oService;

    @Autowired
    private UserService uService;

    @Autowired
    private JWTParam jwtParam;


    @GetMapping("test")
    public void testEmail() throws Exception {

        File file = ResourceUtils.getFile("classpath:templates/temp.xls");
        OutputStream out = new FileOutputStream(file);
        List<List<String>> data = new ArrayList<List<String>>();
        for (int i = 1; i < 50; i++) {
            List rowData = new ArrayList();
            rowData.add(String.valueOf(i));
            rowData.add("东霖柏鸿");
            data.add(rowData);
        }
        String[] headers = { "ID", "用户名" };
        ExportExcelUtils eeu = new ExportExcelUtils();
        HSSFWorkbook workbook = new HSSFWorkbook();
        eeu.exportExcel(workbook, 0, "上海", headers, data, out);
        eeu.exportExcel(workbook, 1, "深圳", headers, data, out);
        eeu.exportExcel(workbook, 2, "广州", headers, data, out);
        //原理就是将所有的数据一起写入，然后再关闭输入流。
        workbook.write(out);
        out.close();

    }

   @PostMapping("login")
    public ResponseVo<?> Login(@RequestBody User user){
        User u = uService.Login(user);
        if (u!=null) {
            String token = JWTUtils.createToken(String.valueOf(u.getId()), jwtParam);
            UserLoginResp resp = new UserLoginResp();
            resp.setUser(u);
            resp.setToken(token);
            return ResponseVo.success(resp);
        }else {
            return ResponseVo.error(CodeEnum.not_found_error,"没有该用户或账号密码不对");
        }
   }

    @PostMapping("")
    public void en(@RequestBody IdRequest ids) throws Exception {
        System.out.println(ids);
        for (String id : ids.getIds()){
            System.out.println(id);
        }
//        File file = ResourceUtils.getFile("classpath:templates/temp.pdf");
//        InsertOrderReq req = oService.GetOneByID("ST201907040001");
//        PDFUtil pdf = new PDFUtil();
//        pdf.CreatePDF(file.getPath(), req);
    }
}
