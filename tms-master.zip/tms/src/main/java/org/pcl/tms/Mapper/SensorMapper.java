package org.pcl.tms.Mapper;

import org.pcl.tms.Model.Sensor;

public interface SensorMapper {
    int deleteByPrimaryKey(String addressCode);

    int insert(Sensor record);

    int insertSelective(Sensor record);

    Sensor selectByPrimaryKey(String addressCode);

    int updateByPrimaryKeySelective(Sensor record);

    int updateByPrimaryKey(Sensor record);
}