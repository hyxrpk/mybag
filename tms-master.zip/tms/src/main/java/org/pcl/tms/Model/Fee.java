package org.pcl.tms.Model;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Setter
@Getter
public class Fee {
    private String feeName;
    private float price;
    private String feeUrl;
    private String feeObject;
    private int isDefault;
}
