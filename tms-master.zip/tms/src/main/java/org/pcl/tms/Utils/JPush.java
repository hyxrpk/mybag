package org.pcl.tms.Utils;


import cn.jiguang.common.resp.APIConnectionException;
import cn.jiguang.common.resp.APIRequestException;
import cn.jpush.api.JPushClient;
import cn.jpush.api.push.PushResult;
import cn.jpush.api.push.model.Message;
import cn.jpush.api.push.model.Platform;
import cn.jpush.api.push.model.PushPayload;
import cn.jpush.api.push.model.audience.Audience;
import cn.jpush.api.push.model.notification.AndroidNotification;
import cn.jpush.api.push.model.notification.IosNotification;
import cn.jpush.api.push.model.notification.Notification;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class JPush {

    private static String AppKey;

    private static String MasterKey;

    @Value("${jg.AppKey}")
    public  void setAppKey(String appKey) {
        this.AppKey = appKey;
    }

    @Value("${jg.MasterKey}")
    public void setMasterKey(String masterKey) {
        this.MasterKey = masterKey;
    }

    public static void Push(String regid, Object msg){
                JPushClient jPushClient = new JPushClient(MasterKey, AppKey);
                PushPayload payload = buildPushObject_all_alias_alert(regid,msg);
                try {
                    PushResult result = jPushClient.sendPush(payload);
                }catch (APIConnectionException e) {
                } catch (APIRequestException e) {
                    e.printStackTrace();
                }
            }

    public static PushPayload buildPushObject_all_alias_alert(String regid, Object msg) {

        return PushPayload.newBuilder()
                .setPlatform(Platform.all())
                .setAudience(Audience.registrationId(regid))
                .setNotification(Notification.newBuilder()
                        .addPlatformNotification(IosNotification.newBuilder().setAlert(msg).setBadge(1).setSound("happy.caf").addExtra("from", "JPush").build())
                        .addPlatformNotification(AndroidNotification.newBuilder().setAlert(msg).setTitle("你有新的订单").build())
                        .build())
                .build();
    }

    public static void main(String []Args){

    }
}
